package com.nerdora.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private fun scheme(theme: String, accent: String) = darkColorScheme(
    primary = when (accent) {
        "ROSE" -> Color(0xFFF472B6)
        "CYAN" -> Color(0xFF22D3EE)
        else -> Color(0xFF8B5CF6)
    },
    onPrimary = Color.White,
    primaryContainer = when (accent) {
        "ROSE" -> Color(0xFF500724)
        "CYAN" -> Color(0xFF083344)
        else -> Color(0xFF2E1065)
    },
    onPrimaryContainer = Color(0xFFF5F3FF),
    secondary = when (accent) {
        "ROSE" -> Color(0xFFF9A8D4)
        "CYAN" -> Color(0xFF67E8F9)
        else -> Color(0xFFC084FC)
    },
    background = if (theme == "AMOLED") Color.Black else Color(0xFF09070D),
    onBackground = Color(0xFFF5F3FF),
    surface = if (theme == "AMOLED") Color(0xFF050505) else Color(0xFF120E18),
    onSurface = Color(0xFFF5F3FF),
    surfaceVariant = if (theme == "AMOLED") Color(0xFF101010) else Color(0xFF21182D),
    onSurfaceVariant = Color(0xFFD8CDE5)
)

@Composable
fun NerdoraTheme(
    themeMode: String = "NERDORA",
    accent: String = "PURPLE",
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = scheme(themeMode, accent),
        content = content
    )
}

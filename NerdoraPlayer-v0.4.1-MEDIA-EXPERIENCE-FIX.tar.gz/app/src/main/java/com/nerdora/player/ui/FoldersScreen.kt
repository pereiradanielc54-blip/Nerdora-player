package com.nerdora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nerdora.player.model.NerdoraMedia

@Composable
fun FoldersScreen(
    items: List<NerdoraMedia>,
    onOpenFolder: (List<NerdoraMedia>) -> Unit
) {
    val groups = items.groupBy { it.folder.ifBlank { "Outros" } }
        .toList()
        .sortedByDescending { it.second.size }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                Text("Pastas e álbuns", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Organização detectada pelo Android", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                items(groups, key = { it.first }) { (name, groupItems) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(15.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { onOpenFolder(groupItems) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(68.dp).clip(RoundedCornerShape(12.dp)).background(
                                Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary, Color(0xFF160A25)))
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            val thumb = groupItems.firstOrNull()?.thumbnailUrl ?: groupItems.firstOrNull()?.url
                            if (thumb != null) {
                                AsyncImage(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            } else {
                                Icon(Icons.Rounded.Folder, null, tint = Color.White, modifier = Modifier.size(34.dp))
                            }
                        }
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${groupItems.size} itens", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                        Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

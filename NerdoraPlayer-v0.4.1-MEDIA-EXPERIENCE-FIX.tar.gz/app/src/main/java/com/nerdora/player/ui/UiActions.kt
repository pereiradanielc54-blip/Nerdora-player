package com.nerdora.player.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.nerdora.player.model.LibrarySort
import com.nerdora.player.model.NerdoraMedia

fun sortMedia(items: List<NerdoraMedia>, sort: LibrarySort): List<NerdoraMedia> = when (sort) {
    LibrarySort.NEWEST -> items.sortedByDescending { it.dateAddedSeconds }
    LibrarySort.OLDEST -> items.sortedBy { it.dateAddedSeconds }
    LibrarySort.NAME -> items.sortedBy { it.title.lowercase() }
    LibrarySort.SIZE -> items.sortedByDescending { it.sizeBytes }
    LibrarySort.DURATION -> items.sortedByDescending { it.durationMs }
}

fun shareMedia(context: Context, items: List<NerdoraMedia>) {
    if (items.isEmpty()) return
    val localUris = items.mapNotNull { runCatching { Uri.parse(it.url) }.getOrNull() }
    val intent = if (localUris.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = items.first().mimeType.ifBlank { "*/*" }
            putExtra(Intent.EXTRA_STREAM, localUris.first())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(localUris))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
    runCatching { context.startActivity(Intent.createChooser(intent, "Compartilhar com")) }
}

package com.nerdora.player.ui

import android.content.ComponentName
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.model.NerdoraMedia
import com.nerdora.player.playback.PlaybackService
import kotlinx.coroutines.delay

@Composable
fun NerdoraAudioPlayer(
    media: NerdoraMedia,
    queue: List<NerdoraMedia>,
    autoplay: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val token = remember { SessionToken(context, ComponentName(context, PlaybackService::class.java)) }
    val controllerFuture = remember { MediaController.Builder(context, token).buildAsync() }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(media.durationMs.coerceAtLeast(1L)) }

    DisposableEffect(controllerFuture) {
        val executor = ContextCompat.getMainExecutor(context)
        controllerFuture.addListener({
            runCatching { controllerFuture.get() }.onSuccess { controller = it }
        }, executor)
        onDispose {
            controller?.let { c -> PlayerPreferences.savePosition(context, media.url, c.currentPosition) }
            MediaController.releaseFuture(controllerFuture)
        }
    }

    LaunchedEffect(controller, media.id, queue.map { it.id }) {
        val c = controller ?: return@LaunchedEffect
        if (c.currentMediaItem?.mediaId != media.id) {
            val actualQueue = queue.filter { it.kind == com.nerdora.player.model.MediaKind.AUDIO }
                .ifEmpty { listOf(media) }
            val index = actualQueue.indexOfFirst { it.id == media.id }.coerceAtLeast(0)
            val mediaItems = actualQueue.map { it.toMediaItem() }
            val start = if (PlayerPreferences.resumePlayback(context)) PlayerPreferences.loadPosition(context, media.url) else 0L
            c.setMediaItems(mediaItems, index, start)
            c.prepare()
            if (autoplay) c.play()
        }
    }

    LaunchedEffect(controller) {
        while (true) {
            controller?.let { c ->
                isPlaying = c.isPlaying
                position = c.currentPosition.coerceAtLeast(0L)
                if (c.duration > 0L) duration = c.duration
                if (position > 5_000L) PlayerPreferences.savePosition(context, c.currentMediaItem?.localConfiguration?.uri.toString(), position)
            }
            delay(300)
        }
    }

    val c = controller
    Box(
        modifier = modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF231038), Color.Black))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(232.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF2E1065)),
                contentAlignment = Alignment.Center
            ) {
                if (media.thumbnailUrl != null) {
                    AsyncImage(media.thumbnailUrl, media.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Icon(Icons.Rounded.LibraryMusic, null, tint = Color.White, modifier = Modifier.size(92.dp))
                }
            }
            Spacer(Modifier.size(22.dp))
            Text(media.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(media.artist.ifBlank { media.description }, color = Color(0xFFD8CDE5), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (media.album.isNotBlank()) Text(media.album, color = Color(0xFF9E8EAA), fontSize = 11.sp)
            Spacer(Modifier.size(20.dp))
            Slider(
                value = position.coerceAtMost(duration.coerceAtLeast(1L)).toFloat(),
                onValueChange = { value -> position = value.toLong(); c?.seekTo(position) },
                valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatDuration(position), color = Color(0xFFCFC3DA), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(formatDuration(duration), color = Color(0xFFCFC3DA), fontSize = 11.sp)
            }
            Spacer(Modifier.size(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                IconButton(onClick = { c?.shuffleModeEnabled = !(c?.shuffleModeEnabled ?: false) }) {
                    Icon(Icons.Rounded.Shuffle, "Aleatório", tint = if (c?.shuffleModeEnabled == true) MaterialTheme.colorScheme.primary else Color.White)
                }
                IconButton(onClick = { c?.seekToPreviousMediaItem() }) { Icon(Icons.Rounded.SkipPrevious, "Anterior", tint = Color.White) }
                Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                    IconButton(onClick = { if (c?.isPlaying == true) c.pause() else c?.play() }, modifier = Modifier.fillMaxSize()) {
                        Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (isPlaying) "Pausar" else "Reproduzir", tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                }
                IconButton(onClick = { c?.seekToNextMediaItem() }) { Icon(Icons.Rounded.SkipNext, "Próxima", tint = Color.White) }
                IconButton(onClick = {
                    c?.repeatMode = when (c?.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }) {
                    Icon(Icons.Rounded.Repeat, "Repetir", tint = if (c?.repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else Color.White)
                }
            }
        }
    }
}

private fun NerdoraMedia.toMediaItem(): MediaItem {
    val metadata = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist.ifBlank { description })
        .setAlbumTitle(album)
        .apply { thumbnailUrl?.let { setArtworkUri(Uri.parse(it)) } }
        .build()
    return MediaItem.Builder()
        .setMediaId(id)
        .setUri(url)
        .setMediaMetadata(metadata)
        .build()
}

package com.nerdora.player.ui

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.data.LocalMediaRepository
import com.nerdora.player.model.NerdoraMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun NerdoraVideoPlayer(
    media: NerdoraMedia,
    autoplay: Boolean,
    onEnterPictureInPicture: () -> Unit,
    onCast: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val seekMs = remember { PlayerPreferences.seekSeconds(context) * 1000L }
    var locked by remember(media.id) { mutableStateOf(false) }
    var resizeMode by remember(media.id) { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var error by remember(media.id) { mutableStateOf<String?>(null) }
    var externalSubtitle by remember(media.id) { mutableStateOf<Uri?>(null) }
    var autoSubtitle by remember(media.id) { mutableStateOf<Uri?>(null) }
    var brightness by remember { mutableFloatStateOf(activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f) }

    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            externalSubtitle = uri
        }
    }

    val player = remember(media.id) {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = autoplay
            addListener(object : Player.Listener {
                override fun onPlayerError(playerError: PlaybackException) {
                    error = playerError.errorCodeName
                }
            })
        }
    }

    LaunchedEffect(media.id) {
        autoSubtitle = withContext(Dispatchers.IO) { LocalMediaRepository.findMatchingSubtitle(context, media) }
    }

    LaunchedEffect(media.id, externalSubtitle, autoSubtitle) {
        val currentPosition = player.currentPosition.coerceAtLeast(0L)
        val subtitle = externalSubtitle ?: autoSubtitle
        val mediaItem = MediaItem.Builder()
            .setUri(media.url)
            .apply {
                if (subtitle != null) {
                    val subtitleMime = if (subtitle.toString().lowercase().endsWith(".vtt")) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
                    setSubtitleConfigurations(
                        listOf(
                            MediaItem.SubtitleConfiguration.Builder(subtitle)
                                .setMimeType(subtitleMime)
                                .setLanguage("pt")
                                .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                                .build()
                        )
                    )
                }
            }
            .build()
        player.setMediaItem(mediaItem)
        player.prepare()
        val saved = if (PlayerPreferences.resumePlayback(context)) PlayerPreferences.loadPosition(context, media.url) else 0L
        player.seekTo(if (currentPosition > 0L) currentPosition else saved)
        if (autoplay) player.play()
    }

    LaunchedEffect(player) {
        while (true) {
            delay(2_000L)
            val pos = player.currentPosition.coerceAtLeast(0L)
            val dur = player.duration
            if (dur > 0L && pos >= dur - 5_000L) PlayerPreferences.clearPosition(context, media.url)
            else if (pos > 5_000L) PlayerPreferences.savePosition(context, media.url, pos)
        }
    }

    DisposableEffect(player) {
        onDispose {
            val pos = player.currentPosition.coerceAtLeast(0L)
            val dur = player.duration
            if (dur > 0L && pos >= dur - 5_000L) PlayerPreferences.clearPosition(context, media.url)
            else PlayerPreferences.savePosition(context, media.url, pos)
            player.release()
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    controllerShowTimeoutMs = 3000
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            update = { view ->
                view.player = player
                view.useController = !locked
                view.resizeMode = resizeMode
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!locked) {
            GestureZone(
                modifier = Modifier.align(Alignment.CenterStart).fillMaxHeight().width(92.dp),
                onDoubleTap = { player.seekTo((player.currentPosition - seekMs).coerceAtLeast(0L)) },
                onVerticalDrag = { delta ->
                    val change = -delta / 900f
                    brightness = (brightness + change).coerceIn(0.05f, 1f)
                    activity?.window?.attributes = activity?.window?.attributes?.apply { screenBrightness = brightness }
                }
            )
            GestureZone(
                modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(92.dp),
                onDoubleTap = { player.seekTo((player.currentPosition + seekMs).coerceAtMost(player.duration.takeIf { it > 0 } ?: Long.MAX_VALUE)) },
                onVerticalDrag = { delta ->
                    val direction = if (delta < 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0)
                }
            )
        }

        Row(
            modifier = Modifier.align(Alignment.TopEnd).fillMaxWidth().padding(top = 42.dp, end = 8.dp, start = 8.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!locked) {
                IconButton(onClick = {
                    resizeMode = when (resizeMode) {
                        AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                }) { Icon(Icons.Rounded.FitScreen, "Ajustar tela", tint = Color.White) }
                IconButton(onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain")) }) {
                    Icon(Icons.Rounded.Subtitles, "Carregar legenda", tint = if (externalSubtitle != null || autoSubtitle != null) MaterialTheme.colorScheme.primary else Color.White)
                }
                IconButton(onClick = {
                    activity?.requestedOrientation = if (activity?.resources?.configuration?.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
                        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                }) { Icon(Icons.Rounded.ScreenRotation, "Girar tela", tint = Color.White) }
                IconButton(onClick = onCast) { Icon(Icons.Rounded.Cast, "Transmitir", tint = Color.White) }
                IconButton(onClick = onEnterPictureInPicture) { Icon(Icons.Rounded.PictureInPictureAlt, "Picture-in-Picture", tint = Color.White) }
            }
            IconButton(onClick = { locked = !locked }) {
                Icon(if (locked) Icons.Rounded.LockOpen else Icons.Rounded.Lock, if (locked) "Desbloquear" else "Bloquear controles", tint = Color.White)
            }
        }

        if (error != null) {
            Text(
                "Não foi possível reproduzir este vídeo ($error). O formato/codec pode não ser suportado neste aparelho.",
                color = Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xCC7F1D1D)).padding(12.dp)
            )
        }
    }
}

@Composable
private fun GestureZone(
    modifier: Modifier,
    onDoubleTap: () -> Unit,
    onVerticalDrag: (Float) -> Unit
) {
    Box(
        modifier = modifier
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { onDoubleTap() }) }
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount -> onVerticalDrag(dragAmount) }
            }
    )
}

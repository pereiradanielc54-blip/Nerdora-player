package com.nerdora.player

import android.content.Context

object PlayerPreferences {
    private const val PREFS = "nerdora_player_prefs"
    private const val AUTOPLAY = "autoplay"
    private const val RESUME = "resume"
    private const val BACKGROUND_AUDIO = "background_audio"
    private const val THEME = "theme"
    private const val ACCENT = "accent"
    private const val SEEK_SECONDS = "seek_seconds"
    private const val SLIDESHOW_SECONDS = "slideshow_seconds"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun autoplay(context: Context): Boolean = prefs(context).getBoolean(AUTOPLAY, true)
    fun setAutoplay(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(AUTOPLAY, enabled).apply()

    fun resumePlayback(context: Context): Boolean = prefs(context).getBoolean(RESUME, true)
    fun setResumePlayback(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(RESUME, enabled).apply()

    fun backgroundAudio(context: Context): Boolean = prefs(context).getBoolean(BACKGROUND_AUDIO, true)
    fun setBackgroundAudio(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(BACKGROUND_AUDIO, enabled).apply()

    fun theme(context: Context): String = prefs(context).getString(THEME, "NERDORA") ?: "NERDORA"
    fun setTheme(context: Context, value: String) = prefs(context).edit().putString(THEME, value).apply()

    fun accent(context: Context): String = prefs(context).getString(ACCENT, "PURPLE") ?: "PURPLE"
    fun setAccent(context: Context, value: String) = prefs(context).edit().putString(ACCENT, value).apply()

    fun seekSeconds(context: Context): Int = prefs(context).getInt(SEEK_SECONDS, 10).coerceIn(5, 30)
    fun setSeekSeconds(context: Context, seconds: Int) = prefs(context).edit().putInt(SEEK_SECONDS, seconds.coerceIn(5, 30)).apply()

    fun slideshowSeconds(context: Context): Int = prefs(context).getInt(SLIDESHOW_SECONDS, 4).coerceIn(2, 10)
    fun setSlideshowSeconds(context: Context, seconds: Int) = prefs(context).edit().putInt(SLIDESHOW_SECONDS, seconds.coerceIn(2, 10)).apply()

    fun loadPosition(context: Context, mediaKey: String): Long =
        prefs(context).getLong("position_${mediaKey.hashCode()}", 0L)

    fun savePosition(context: Context, mediaKey: String, positionMs: Long) {
        val key = "position_${mediaKey.hashCode()}"
        if (positionMs < 5_000L) prefs(context).edit().remove(key).apply()
        else prefs(context).edit().putLong(key, positionMs).apply()
    }

    fun clearPosition(context: Context, mediaKey: String) =
        prefs(context).edit().remove("position_${mediaKey.hashCode()}").apply()
}

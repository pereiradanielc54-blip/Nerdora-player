package com.nerdora.player

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class UpdateResult(
    val latestVersion: String,
    val releaseUrl: String,
    val hasUpdate: Boolean,
    val message: String
)

object UpdateChecker {
    suspend fun check(repository: String, currentVersion: String): UpdateResult = withContext(Dispatchers.IO) {
        if (repository.isBlank()) {
            return@withContext UpdateResult("", "", false, "Repositório não informado no build.")
        }
        runCatching {
            val connection = (URL("https://api.github.com/repos/$repository/releases/latest").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("User-Agent", "Nerdora-Player")
            }
            val code = connection.responseCode
            if (code !in 200..299) {
                connection.disconnect()
                return@runCatching UpdateResult("", "", false, "Nenhuma release pública encontrada (HTTP $code).")
            }
            val json = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val obj = JSONObject(json)
            val tag = obj.optString("tag_name").removePrefix("v")
            val url = obj.optString("html_url")
            val hasUpdate = compareVersions(tag, currentVersion.removeSuffix("-debug")) > 0
            UpdateResult(
                latestVersion = tag,
                releaseUrl = url,
                hasUpdate = hasUpdate,
                message = if (hasUpdate) "Nova versão $tag disponível" else "Você já está na versão mais recente."
            )
        }.getOrElse {
            UpdateResult("", "", false, "Não foi possível verificar atualizações: ${it.message ?: "erro de rede"}")
        }
    }

    private fun compareVersions(a: String, b: String): Int {
        val aa = a.split('.').map { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        val bb = b.split('.').map { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        val size = maxOf(aa.size, bb.size)
        for (i in 0 until size) {
            val av = aa.getOrElse(i) { 0 }
            val bv = bb.getOrElse(i) { 0 }
            if (av != bv) return av.compareTo(bv)
        }
        return 0
    }
}

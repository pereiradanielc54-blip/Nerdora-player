package com.nerdora.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.nerdora.player.LibraryStore
import com.nerdora.player.MainActivity
import com.nerdora.player.MediaPermissions
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.data.LocalMediaRepository
import com.nerdora.player.data.SampleMedia
import com.nerdora.player.model.NerdoraMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class AppScreen { HOME, LIBRARY, FOLDERS, PLAYLISTS, SETTINGS, HIDDEN }

@Composable
fun NerdoraPlayerApp(
    activity: MainActivity,
    externalMedia: NerdoraMedia?,
    onEnterPictureInPicture: () -> Unit,
    onThemeChanged: () -> Unit
) {
    var screenName by rememberSaveable { mutableStateOf(AppScreen.HOME.name) }
    var localMedia by remember { mutableStateOf<List<NerdoraMedia>>(emptyList()) }
    var permissionEpoch by remember { mutableIntStateOf(0) }
    var storeEpoch by remember { mutableIntStateOf(0) }
    var hasMediaAccess by remember { mutableStateOf(MediaPermissions.hasAnyAccess(activity)) }
    var viewerItems by remember { mutableStateOf<List<NerdoraMedia>>(emptyList()) }
    var viewerIndex by rememberSaveable { mutableStateOf<Int?>(if (externalMedia != null) 0 else null) }
    var libraryOverride by remember { mutableStateOf<List<NerdoraMedia>?>(null) }
    var libraryFavoritesOnly by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasMediaAccess = MediaPermissions.hasAnyAccess(activity)
        permissionEpoch++
    }

    LaunchedEffect(permissionEpoch, hasMediaAccess) {
        localMedia = withContext(Dispatchers.IO) { LocalMediaRepository.loadAll(activity) }
    }

    LaunchedEffect(externalMedia?.id) {
        if (externalMedia != null) {
            viewerItems = listOf(externalMedia)
            viewerIndex = 0
        }
    }

    val hiddenIds = remember(localMedia, storeEpoch) { LibraryStore.hiddenIds(activity) }
    val favoriteIds = remember(localMedia, storeEpoch) { LibraryStore.favoriteIds(activity) }
    val recentIds = remember(localMedia, storeEpoch) { LibraryStore.recentIds(activity) }
    val playlists = remember(localMedia, storeEpoch) { LibraryStore.playlists(activity) }
    val visibleMedia = remember(localMedia, hiddenIds) { localMedia.filterNot { hiddenIds.contains(it.id) } }
    val hiddenMedia = remember(localMedia, hiddenIds) { localMedia.filter { hiddenIds.contains(it.id) } }

    val selected = viewerIndex
    if (selected != null) {
        val items = viewerItems.ifEmpty { externalMedia?.let { listOf(it) } ?: SampleMedia.items }
        MediaViewerScreen(
            activity = activity,
            items = items,
            initialIndex = selected.coerceIn(items.indices),
            autoplay = PlayerPreferences.autoplay(activity),
            onClose = { viewerIndex = null },
            onEnterPictureInPicture = onEnterPictureInPicture,
            onStoreChanged = { storeEpoch++ }
        )
        return
    }

    val screen = runCatching { AppScreen.valueOf(screenName) }.getOrDefault(AppScreen.HOME)

    fun openItems(items: List<NerdoraMedia>, index: Int) {
        if (items.isEmpty()) return
        viewerItems = items
        viewerIndex = index.coerceIn(items.indices)
    }

    fun openPrivate() {
        activity.authenticatePrivateMedia { success ->
            if (success) screenName = AppScreen.HIDDEN.name
        }
    }

    Scaffold(
        bottomBar = {
            if (screen != AppScreen.HIDDEN) {
                NavigationBar {
                    listOf(
                        Triple(AppScreen.HOME, "Início", Icons.Rounded.Home),
                        Triple(AppScreen.LIBRARY, "Biblioteca", Icons.Rounded.PermMedia),
                        Triple(AppScreen.FOLDERS, "Pastas", Icons.Rounded.Folder),
                        Triple(AppScreen.PLAYLISTS, "Playlists", Icons.Rounded.LibraryMusic),
                        Triple(AppScreen.SETTINGS, "Ajustes", Icons.Rounded.Settings)
                    ).forEach { (target, label, icon) ->
                        NavigationBarItem(
                            selected = screen == target,
                            onClick = {
                                screenName = target.name
                                if (target == AppScreen.LIBRARY) {
                                    libraryOverride = null
                                    libraryFavoritesOnly = false
                                }
                            },
                            icon = { Icon(icon, label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        androidx.compose.foundation.layout.Box(Modifier.padding(padding)) {
            when (screen) {
                AppScreen.HOME -> HomeScreen(
                    items = visibleMedia,
                    demoItems = SampleMedia.items,
                    hasMediaAccess = hasMediaAccess,
                    favoriteIds = favoriteIds,
                    recentIds = recentIds,
                    hiddenCount = hiddenMedia.size,
                    positionFor = { PlayerPreferences.loadPosition(activity, it.url) },
                    onRequestPermissions = { permissionLauncher.launch(MediaPermissions.permissionsToRequest()) },
                    onOpenItems = ::openItems,
                    onOpenLibrary = {
                        libraryOverride = null
                        libraryFavoritesOnly = false
                        screenName = AppScreen.LIBRARY.name
                    },
                    onOpenFolders = { screenName = AppScreen.FOLDERS.name },
                    onOpenFavorites = {
                        libraryOverride = null
                        libraryFavoritesOnly = true
                        screenName = AppScreen.LIBRARY.name
                    },
                    onOpenPrivate = ::openPrivate
                )
                AppScreen.LIBRARY -> LibraryScreen(
                    items = libraryOverride ?: visibleMedia,
                    favoriteIds = favoriteIds,
                    initialFavoritesOnly = libraryFavoritesOnly,
                    onOpenItems = ::openItems,
                    onRefresh = { permissionEpoch++ },
                    onFavorite = { id, value -> LibraryStore.setFavorite(activity, id, value); storeEpoch++ },
                    onHide = { id, value -> LibraryStore.setHidden(activity, id, value); storeEpoch++ },
                    onShare = { shareMedia(activity, it) }
                )
                AppScreen.FOLDERS -> FoldersScreen(
                    items = visibleMedia,
                    onOpenFolder = { group ->
                        libraryOverride = group
                        libraryFavoritesOnly = false
                        screenName = AppScreen.LIBRARY.name
                    }
                )
                AppScreen.PLAYLISTS -> PlaylistsScreen(
                    playlists = playlists,
                    allItems = visibleMedia,
                    onCreate = { LibraryStore.createPlaylist(activity, it); storeEpoch++ },
                    onDelete = { LibraryStore.deletePlaylist(activity, it); storeEpoch++ },
                    onOpen = { if (it.isNotEmpty()) openItems(it, 0) }
                )
                AppScreen.SETTINGS -> SettingsScreen(
                    hiddenCount = hiddenMedia.size,
                    onThemeChanged = onThemeChanged,
                    onOpenPrivate = ::openPrivate,
                    onClearHistory = { LibraryStore.clearHistory(activity); storeEpoch++ },
                    onOpenCastSettings = activity::openCastSettings
                )
                AppScreen.HIDDEN -> HiddenScreen(
                    items = hiddenMedia,
                    onOpenItems = ::openItems,
                    onUnhide = { LibraryStore.setHidden(activity, it, false); storeEpoch++ }
                )
            }
        }
    }
}

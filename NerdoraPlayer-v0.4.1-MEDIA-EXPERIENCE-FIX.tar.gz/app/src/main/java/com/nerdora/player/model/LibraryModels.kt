package com.nerdora.player.model

enum class LibrarySort(val label: String) {
    NEWEST("Mais recentes"),
    OLDEST("Mais antigos"),
    NAME("Nome"),
    SIZE("Tamanho"),
    DURATION("Duração")
}

enum class LibraryFilter(val label: String) {
    ALL("Tudo"), IMAGE("Fotos"), VIDEO("Vídeos"), AUDIO("Músicas")
}

data class MediaFolder(
    val name: String,
    val items: List<NerdoraMedia>
)

data class TechnicalInfo(
    val mimeType: String = "",
    val width: Int = 0,
    val height: Int = 0,
    val bitrate: Long = 0L,
    val frameRate: Float = 0f,
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L
)

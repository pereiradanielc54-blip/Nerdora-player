package com.nerdora.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Rational
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia
import com.nerdora.player.ui.NerdoraPlayerApp
import com.nerdora.player.ui.NerdoraTheme

class MainActivity : FragmentActivity() {

    private val incomingMedia = mutableStateOf<NerdoraMedia?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        incomingMedia.value = parseIncomingMedia(intent)

        setContent {
            var themeMode by remember { mutableStateOf(PlayerPreferences.theme(this)) }
            var accent by remember { mutableStateOf(PlayerPreferences.accent(this)) }
            NerdoraTheme(themeMode = themeMode, accent = accent) {
                NerdoraPlayerApp(
                    activity = this,
                    externalMedia = incomingMedia.value,
                    onEnterPictureInPicture = { enterNerdoraPip() },
                    onThemeChanged = {
                        themeMode = PlayerPreferences.theme(this)
                        accent = PlayerPreferences.accent(this)
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingMedia.value = parseIncomingMedia(intent)
    }

    private fun parseIncomingMedia(intent: Intent?): NerdoraMedia? {
        if (intent == null || intent.action != Intent.ACTION_VIEW) return null
        val uri: Uri = intent.data ?: return null
        val mime = intent.type.orEmpty()
        val kind = when {
            mime.startsWith("image/") -> MediaKind.IMAGE
            mime.startsWith("video/") -> MediaKind.VIDEO
            mime.startsWith("audio/") -> MediaKind.AUDIO
            uri.getQueryParameter("type")?.equals("image", ignoreCase = true) == true -> MediaKind.IMAGE
            uri.getQueryParameter("type")?.equals("audio", ignoreCase = true) == true -> MediaKind.AUDIO
            else -> MediaKind.VIDEO
        }
        val resolvedUrl = if (uri.scheme == "nerdora" && uri.host == "player") {
            uri.getQueryParameter("url") ?: return null
        } else uri.toString()
        return NerdoraMedia(
            id = "external-${resolvedUrl.hashCode()}",
            kind = kind,
            url = resolvedUrl,
            thumbnailUrl = uri.getQueryParameter("thumbnail"),
            title = uri.getQueryParameter("title") ?: "Mídia Nerdora",
            description = uri.getQueryParameter("description").orEmpty(),
            username = uri.getQueryParameter("user") ?: "@nerdora",
            mimeType = mime
        )
    }

    fun enterNerdoraPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    fun openCastSettings() {
        runCatching {
            startActivity(Intent("android.settings.CAST_SETTINGS"))
        }.onFailure {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    fun authenticatePrivateMedia(onResult: (Boolean) -> Unit) {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            onResult(false)
            return
        }
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(true)
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(false)
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Mídia oculta do Nerdora Player")
            .setSubtitle("Confirme sua identidade para continuar")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    }
}

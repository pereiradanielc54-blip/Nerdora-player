package com.nerdora.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nerdora.player.model.NerdoraMedia

@Composable
fun HiddenScreen(
    items: List<NerdoraMedia>,
    onOpenItems: (List<NerdoraMedia>, Int) -> Unit,
    onUnhide: (String) -> Unit
) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(18.dp)) {
                Text("Mídia oculta", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Área protegida pelo bloqueio do aparelho. Os arquivos não são criptografados nem movidos.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhuma mídia oculta", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(145.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    itemsIndexed(items, key = { _, item -> item.id }) { index, item ->
                        Column {
                            MediaCard(
                                media = item,
                                modifier = Modifier.fillMaxWidth().height(190.dp),
                                onClick = { onOpenItems(items, index) }
                            )
                            Button(onClick = { onUnhide(item.id) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Rounded.LockOpen, null)
                                Text("Mostrar")
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.nerdora.player.model

enum class MediaKind { IMAGE, VIDEO, AUDIO }

data class NerdoraMedia(
    val id: String,
    val kind: MediaKind,
    val url: String,
    val thumbnailUrl: String? = null,
    val title: String = "",
    val description: String = "",
    val username: String = "@nerdora",
    val avatarUrl: String? = null,
    val likes: Int = 0,
    val comments: Int = 0,
    val views: Int = 0,
    val durationMs: Long = 0L,
    val dateAddedSeconds: Long = 0L,
    val dateModifiedSeconds: Long = 0L,
    val folder: String = "",
    val artist: String = "",
    val album: String = "",
    val mimeType: String = "",
    val sizeBytes: Long = 0L,
    val width: Int = 0,
    val height: Int = 0
) {
    val isLocal: Boolean get() = url.startsWith("content://") || url.startsWith("file://")
}

package com.nerdora.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object LibraryStore {
    private const val PREFS = "nerdora_library_store"
    private const val FAVORITES = "favorites"
    private const val HIDDEN = "hidden"
    private const val RECENTS = "recents"
    private const val PLAYLISTS = "playlists"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun favoriteIds(context: Context): Set<String> =
        prefs(context).getStringSet(FAVORITES, emptySet())?.toSet().orEmpty()

    fun isFavorite(context: Context, id: String): Boolean = favoriteIds(context).contains(id)

    fun setFavorite(context: Context, id: String, value: Boolean) {
        val set = favoriteIds(context).toMutableSet()
        if (value) set += id else set -= id
        prefs(context).edit().putStringSet(FAVORITES, set).apply()
    }

    fun hiddenIds(context: Context): Set<String> =
        prefs(context).getStringSet(HIDDEN, emptySet())?.toSet().orEmpty()

    fun isHidden(context: Context, id: String): Boolean = hiddenIds(context).contains(id)

    fun setHidden(context: Context, id: String, value: Boolean) {
        val set = hiddenIds(context).toMutableSet()
        if (value) set += id else set -= id
        prefs(context).edit().putStringSet(HIDDEN, set).apply()
    }

    fun recordOpened(context: Context, id: String) {
        val current = recentIds(context).toMutableList()
        current.remove(id)
        current.add(0, id)
        while (current.size > 80) current.removeLast()
        prefs(context).edit().putString(RECENTS, JSONArray(current).toString()).apply()
    }

    fun recentIds(context: Context): List<String> {
        val raw = prefs(context).getString(RECENTS, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) add(array.optString(i))
            }.filter { it.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    fun clearHistory(context: Context) {
        prefs(context).edit().remove(RECENTS).apply()
    }

    fun playlists(context: Context): Map<String, List<String>> {
        val raw = prefs(context).getString(PLAYLISTS, "{}") ?: "{}"
        return runCatching {
            val obj = JSONObject(raw)
            val map = linkedMapOf<String, List<String>>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val array = obj.optJSONArray(key) ?: JSONArray()
                val ids = buildList {
                    for (i in 0 until array.length()) add(array.optString(i))
                }.filter { it.isNotBlank() }
                map[key] = ids
            }
            map
        }.getOrDefault(emptyMap())
    }

    fun createPlaylist(context: Context, name: String) {
        val clean = name.trim()
        if (clean.isBlank()) return
        val all = playlists(context).toMutableMap()
        if (!all.containsKey(clean)) all[clean] = emptyList()
        savePlaylists(context, all)
    }

    fun deletePlaylist(context: Context, name: String) {
        val all = playlists(context).toMutableMap()
        all.remove(name)
        savePlaylists(context, all)
    }

    fun addToPlaylist(context: Context, name: String, id: String) {
        val all = playlists(context).toMutableMap()
        val ids = all[name].orEmpty().toMutableList()
        if (!ids.contains(id)) ids += id
        all[name] = ids
        savePlaylists(context, all)
    }

    fun removeFromPlaylist(context: Context, name: String, id: String) {
        val all = playlists(context).toMutableMap()
        all[name] = all[name].orEmpty().filterNot { it == id }
        savePlaylists(context, all)
    }

    private fun savePlaylists(context: Context, playlists: Map<String, List<String>>) {
        val obj = JSONObject()
        playlists.forEach { (name, ids) -> obj.put(name, JSONArray(ids)) }
        prefs(context).edit().putString(PLAYLISTS, obj.toString()).apply()
    }
}

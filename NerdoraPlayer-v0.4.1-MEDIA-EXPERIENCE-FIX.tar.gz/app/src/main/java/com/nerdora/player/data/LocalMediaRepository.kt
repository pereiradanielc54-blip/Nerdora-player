package com.nerdora.player.data

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia
import com.nerdora.player.model.TechnicalInfo

object LocalMediaRepository {

    fun loadAll(context: Context): List<NerdoraMedia> {
        val result = mutableListOf<NerdoraMedia>()
        result += runCatching { loadImages(context) }.getOrDefault(emptyList())
        result += runCatching { loadVideos(context) }.getOrDefault(emptyList())
        result += runCatching { loadAudio(context) }.getOrDefault(emptyList())
        return result.sortedByDescending { it.dateAddedSeconds }
    }

    private fun loadImages(context: Context): List<NerdoraMedia> {
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT
        )
        val items = mutableListOf<NerdoraMedia>()
        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
            val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                items += NerdoraMedia(
                    id = "local-image-$id",
                    kind = MediaKind.IMAGE,
                    url = uri.toString(),
                    thumbnailUrl = uri.toString(),
                    title = cursor.getString(nameCol) ?: "Foto",
                    description = "Foto do seu dispositivo",
                    username = "Meu celular",
                    dateAddedSeconds = cursor.getLong(addedCol),
                    dateModifiedSeconds = cursor.getLong(modifiedCol),
                    folder = cursor.getString(bucketCol)?.takeIf { it.isNotBlank() } ?: "Imagens",
                    mimeType = cursor.getString(mimeCol).orEmpty(),
                    sizeBytes = cursor.getLong(sizeCol),
                    width = cursor.getInt(widthCol),
                    height = cursor.getInt(heightCol)
                )
            }
        }
        return items
    }

    private fun loadVideos(context: Context): List<NerdoraMedia> {
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT
        )
        val items = mutableListOf<NerdoraMedia>()
        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                items += NerdoraMedia(
                    id = "local-video-$id",
                    kind = MediaKind.VIDEO,
                    url = uri.toString(),
                    thumbnailUrl = uri.toString(),
                    title = cursor.getString(nameCol) ?: "Vídeo",
                    description = "Vídeo do seu dispositivo",
                    username = "Meu celular",
                    durationMs = cursor.getLong(durationCol),
                    dateAddedSeconds = cursor.getLong(addedCol),
                    dateModifiedSeconds = cursor.getLong(modifiedCol),
                    folder = cursor.getString(bucketCol)?.takeIf { it.isNotBlank() } ?: "Vídeos",
                    mimeType = cursor.getString(mimeCol).orEmpty(),
                    sizeBytes = cursor.getLong(sizeCol),
                    width = cursor.getInt(widthCol),
                    height = cursor.getInt(heightCol)
                )
            }
        }
        return items
    }

    private fun loadAudio(context: Context): List<NerdoraMedia> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val items = mutableListOf<NerdoraMedia>()
        context.contentResolver.query(
            collection,
            projection,
            selection,
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val displayNameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                val displayName = cursor.getString(displayNameCol) ?: "Música"
                val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: displayName
                val artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                    ?: "Artista desconhecido"
                val album = cursor.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                    ?: "Sem álbum"
                val albumId = cursor.getLong(albumIdCol)
                val albumArt = if (albumId > 0) {
                    ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    ).toString()
                } else null
                items += NerdoraMedia(
                    id = "local-audio-$id",
                    kind = MediaKind.AUDIO,
                    url = uri.toString(),
                    thumbnailUrl = albumArt,
                    title = title,
                    description = artist,
                    username = "Músicas do aparelho",
                    durationMs = cursor.getLong(durationCol),
                    dateAddedSeconds = cursor.getLong(addedCol),
                    dateModifiedSeconds = cursor.getLong(modifiedCol),
                    folder = album,
                    artist = artist,
                    album = album,
                    mimeType = cursor.getString(mimeCol).orEmpty(),
                    sizeBytes = cursor.getLong(sizeCol)
                )
            }
        }
        return items
    }

    fun findMatchingSubtitle(context: Context, media: NerdoraMedia): Uri? {
        if (!media.isLocal || media.kind != MediaKind.VIDEO) return null
        val base = media.title.substringBeforeLast('.', media.title)
        if (base.isBlank()) return null
        val collection = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME)
        val selection = "${MediaStore.Files.FileColumns.DISPLAY_NAME}=? OR ${MediaStore.Files.FileColumns.DISPLAY_NAME}=?"
        val args = arrayOf("$base.srt", "$base.vtt")
        return runCatching {
            context.contentResolver.query(collection, projection, selection, args, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                if (cursor.moveToFirst()) ContentUris.withAppendedId(collection, cursor.getLong(idCol)) else null
            }
        }.getOrNull()
    }

    fun loadTechnicalInfo(context: Context, media: NerdoraMedia): TechnicalInfo {
        var width = media.width
        var height = media.height
        var duration = media.durationMs
        var bitrate = 0L
        var frameRate = 0f
        var mime = media.mimeType
        if (media.kind != MediaKind.IMAGE) {
            runCatching {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, Uri.parse(media.url))
                    width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: width
                    height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: height
                    duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: duration
                    bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L
                    frameRate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull() ?: 0f
                    mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: mime
                } finally {
                    retriever.release()
                }
            }
        }
        return TechnicalInfo(
            mimeType = mime,
            width = width,
            height = height,
            bitrate = bitrate,
            frameRate = frameRate,
            durationMs = duration,
            sizeBytes = media.sizeBytes
        )
    }
}

# Nerdora Player release rules
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keep class coil.** { *; }
-dontwarn coil.**

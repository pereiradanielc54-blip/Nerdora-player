# Nerdora Player v0.4.0 — Media Experience

Versão profissional do Nerdora Player para Android, criada em Kotlin + Jetpack Compose + Media3.

## Principais recursos

- Home com **Continuar assistindo**, recentes, favoritos, vídeos, fotos e músicas.
- Biblioteca local via MediaStore com **busca global**, filtros e ordenação.
- Pastas/álbuns detectados automaticamente.
- Seleção múltipla para favoritar, compartilhar e ocultar.
- Favoritos, histórico, playlists e filas locais.
- Player de vídeo Media3/ExoPlayer com PiP, controles nativos avançados, velocidade, faixas de áudio/legendas quando disponíveis, ajuste Fit/Zoom/Fill, bloqueio de controles, rotação, duplo toque para avançar/voltar e gestos laterais de brilho/volume.
- Legendas externas `.srt` / `.vtt` por seletor de arquivos e busca automática best-effort por arquivo de mesmo nome.
- Player de música com fila, aleatório, repetir, anterior/próxima, MediaSession, áudio em segundo plano e controles do sistema/tela de bloqueio.
- Fotos com zoom, rotação e apresentação automática.
- Informações técnicas: MIME, resolução, FPS quando disponível, bitrate, duração e tamanho.
- Área de mídia oculta protegida por biometria ou credencial do aparelho. **Atenção:** isso apenas oculta dentro do Nerdora Player; não criptografa nem move os arquivos.
- Tema Nerdora e Preto AMOLED, com destaque roxo/rosa/ciano.
- `Abrir com Nerdora Player` para foto, vídeo e áudio.
- Launcher para Android TV e interface responsiva básica.
- Atalho para transmissão/espelhamento do Android. Cast direto de arquivos `content://` locais depende do dispositivo/rede e não é prometido pelo app.
- Verificação de atualizações via GitHub Releases. O workflow injeta automaticamente `owner/repository` no BuildConfig.
- Workflow com APK de teste e suporte opcional a **APK Release assinado permanentemente** via GitHub Secrets.

## Compilar pelo GitHub

No repositório, mantenha o pacote `NerdoraPlayer-v0.4.0-MEDIA-EXPERIENCE.tar.gz` e o workflow em:

`.github/workflows/nerdora-player-build.yml`

Depois abra **Actions → Nerdora Player - Build Profissional → Run workflow**.

O APK de teste aparece nos Artifacts como `Nerdora-Player-v0.4.0`.

## Assinatura permanente (recomendado)

O workflow reconhece estes Secrets:

- `NERDORA_KEYSTORE_BASE64`
- `NERDORA_KEYSTORE_PASSWORD`
- `NERDORA_KEY_ALIAS`
- `NERDORA_KEY_PASSWORD`

Quando os quatro estiverem configurados, além do APK de teste ele gera `Nerdora-Player-v0.4.0-release.apk`, com ProGuard/R8 e assinatura permanente.

Para transformar um arquivo `.jks` em Base64 no Linux/macOS:

```bash
base64 -w 0 nerdora-release.jks
```

No PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("nerdora-release.jks"))
```

Guarde a chave e as senhas em local seguro. Se a chave de assinatura for perdida, futuras versões não poderão atualizar uma instalação assinada com ela.

## Publicar atualização automática

Se o workflow tiver os Secrets de assinatura e você criar uma tag como `v0.4.0`, ele cria uma GitHub Release e anexa o APK Release. A tela **Configurações → Verificar atualizações** consulta a última Release do próprio repositório.

## Observações

- `compileSdk = 35`, `targetSdk = 35`, Java 17, Gradle 8.9, AGP 8.7.3.
- O projeto usa permissões modernas `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO` e `READ_MEDIA_AUDIO`; em Android 14 também respeita acesso visual selecionado pelo usuário.
- A grade de demonstração permanece no código (`SampleMedia`) para testes quando a biblioteca local estiver vazia.

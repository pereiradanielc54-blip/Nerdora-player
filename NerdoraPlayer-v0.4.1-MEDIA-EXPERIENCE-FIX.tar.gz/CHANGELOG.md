# Changelog

## 0.4.0 — Media Experience

- Nova Home profissional.
- Busca, filtros, ordenação, pastas e álbuns.
- Histórico, continuar reprodução e favoritos.
- Playlists e fila de músicas.
- MediaSession + serviço de áudio em segundo plano.
- Controles na tela bloqueada/notificação pelo Media3.
- Player de vídeo com gestos de brilho/volume, duplo toque, PiP, bloqueio, Fit/Zoom/Fill e rotação.
- Legendas externas e detecção automática best-effort.
- Slideshow e rotação de fotos.
- Informações técnicas da mídia.
- Multi-seleção e compartilhamento.
- Área oculta com autenticação do aparelho.
- Tema AMOLED e cores de destaque.
- Integração com Android TV e atalho de transmissão do sistema.
- Verificador de atualizações do GitHub.
- Build Release assinado via GitHub Secrets.

package com.nerdora.player.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.nerdora.player.PlayerPreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun NerdoraVideoPlayer(
    url: String,
    autoplay: Boolean,
    onEnterPictureInPicture: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            val resumeAt = PlayerPreferences.loadPosition(context, url)
            if (resumeAt > 0L) seekTo(resumeAt)
            prepare()
            playWhenReady = autoplay
        }
    }

    var isPlaying by remember(url) { mutableStateOf(player.isPlaying) }
    var isBuffering by remember(url) { mutableStateOf(false) }
    var position by remember(url) { mutableLongStateOf(0L) }
    var duration by remember(url) { mutableLongStateOf(0L) }
    var controlsVisible by remember(url) { mutableStateOf(true) }
    var muted by remember(url) { mutableStateOf(false) }
    var captionsEnabled by remember(url) { mutableStateOf(true) }
    var speed by remember(url) { mutableFloatStateOf(1f) }
    var speedMenu by remember { mutableStateOf(false) }
    var qualityMenu by remember { mutableStateOf(false) }
    var qualityLabel by remember(url) { mutableStateOf("Auto") }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(value: Boolean) {
                isPlaying = value
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                duration = player.duration.takeIf { it > 0 } ?: 0L
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            if (player.playbackState == Player.STATE_ENDED) {
                PlayerPreferences.clearPosition(context, url)
            } else {
                PlayerPreferences.savePosition(context, url, player.currentPosition)
            }
            player.release()
        }
    }

    LaunchedEffect(player) {
        while (isActive) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.takeIf { it > 0 } ?: duration
            delay(250)
        }
    }

    LaunchedEffect(controlsVisible, isPlaying) {
        if (controlsVisible && isPlaying) {
            delay(3000)
            controlsVisible = false
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(url) {
                detectTapGestures(
                    onTap = { controlsVisible = !controlsVisible },
                    onDoubleTap = { tap ->
                        if (tap.x < size.width / 2f) {
                            player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
                        } else {
                            val max = duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                            player.seekTo((player.currentPosition + 10_000L).coerceAtMost(max))
                        }
                        controlsVisible = true
                    }
                )
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    this.player = player
                }
            },
            update = { it.player = player }
        )

        if (isBuffering) {
            Box(modifier = Modifier.align(Alignment.Center), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                Text("N", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Black)
            }
        }

        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x44000000))
            ) {
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RoundControl(onClick = {
                        player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
                        controlsVisible = true
                    }) {
                        Icon(Icons.Rounded.Replay10, contentDescription = "Voltar 10 segundos", tint = Color.White)
                    }

                    RoundControl(size = 72, onClick = {
                        if (player.isPlaying) player.pause() else player.play()
                        controlsVisible = true
                    }) {
                        Icon(
                            if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (isPlaying) "Pausar" else "Reproduzir",
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    RoundControl(onClick = {
                        val max = duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                        player.seekTo((player.currentPosition + 10_000L).coerceAtMost(max))
                        controlsVisible = true
                    }) {
                        Icon(Icons.Rounded.Forward10, contentDescription = "Avançar 10 segundos", tint = Color.White)
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color(0x9909070D))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Slider(
                        value = position.coerceAtMost(duration.coerceAtLeast(1L)).toFloat(),
                        onValueChange = {
                            position = it.toLong()
                            player.seekTo(position)
                            controlsVisible = true
                        },
                        valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${formatDuration(position)} / ${formatDuration(duration)}",
                            color = Color.White,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.weight(1f))

                        IconButton(onClick = {
                            muted = !muted
                            player.volume = if (muted) 0f else 1f
                            controlsVisible = true
                        }) {
                            Icon(
                                if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                contentDescription = if (muted) "Ativar som" else "Silenciar",
                                tint = Color.White
                            )
                        }

                        Box {
                            IconButton(onClick = {
                                speedMenu = true
                                controlsVisible = true
                            }) {
                                Icon(Icons.Rounded.Speed, contentDescription = "Velocidade", tint = Color.White)
                            }
                            DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                                listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text("${option}x${if (option == speed) "  ✓" else ""}") },
                                        onClick = {
                                            speed = option
                                            player.setPlaybackSpeed(option)
                                            speedMenu = false
                                            controlsVisible = true
                                        }
                                    )
                                }
                            }
                        }

                        IconButton(onClick = {
                            captionsEnabled = !captionsEnabled
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !captionsEnabled)
                                .build()
                            controlsVisible = true
                        }) {
                            Icon(
                                Icons.Rounded.ClosedCaption,
                                contentDescription = "Legendas",
                                tint = if (captionsEnabled) MaterialTheme.colorScheme.secondary else Color.White
                            )
                        }

                        Box {
                            IconButton(onClick = {
                                qualityMenu = true
                                controlsVisible = true
                            }) {
                                Icon(Icons.Rounded.HighQuality, contentDescription = "Qualidade $qualityLabel", tint = Color.White)
                            }
                            DropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                                val qualities = listOf(
                                    "Auto" to Pair(Int.MAX_VALUE, Int.MAX_VALUE),
                                    "1080p" to Pair(1920, 1080),
                                    "720p" to Pair(1280, 720),
                                    "480p" to Pair(854, 480),
                                    "360p" to Pair(640, 360)
                                )
                                qualities.forEach { (label, size) ->
                                    DropdownMenuItem(
                                        text = { Text("$label${if (qualityLabel == label) "  ✓" else ""}") },
                                        onClick = {
                                            qualityLabel = label
                                            player.trackSelectionParameters = player.trackSelectionParameters
                                                .buildUpon()
                                                .setMaxVideoSize(size.first, size.second)
                                                .build()
                                            qualityMenu = false
                                            controlsVisible = true
                                        }
                                    )
                                }
                            }
                        }

                        IconButton(onClick = {
                            if (isPlaying) controlsVisible = false
                            onEnterPictureInPicture()
                        }) {
                            Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = "Picture-in-Picture", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundControl(
    size: Int = 56,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .background(Color(0xAA21182D), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

# Changelog

## 0.4.2 — UX Refinement

- Auto-ocultação dos controles de vídeo após 4 segundos.
- Barra superior do visualizador acompanha a visibilidade dos controles do vídeo.
- Configurações de vídeo movidas para bottom sheet.
- Correção do swipe entre fotos sem perder zoom/pan/rotação.
- Mini player de música persistente dentro do app.
- Barra de progresso, play/pause, próxima e expansão para o player completo.

## 0.4.0 — Media Experience

- Nova Home profissional.
- Busca, filtros, ordenação, pastas e álbuns.
- Histórico, continuar reprodução e favoritos.
- Playlists e fila de músicas.
- MediaSession + serviço de áudio em segundo plano.
- Controles na tela bloqueada/notificação pelo Media3.
- Player de vídeo com gestos de brilho/volume, duplo toque, PiP, bloqueio, Fit/Zoom/Fill e rotação.
- Legendas externas e detecção automática best-effort.
- Slideshow e rotação de fotos.
- Informações técnicas da mídia.
- Multi-seleção e compartilhamento.
- Área oculta com autenticação do aparelho.
- Tema AMOLED e cores de destaque.
- Integração com Android TV e atalho de transmissão do sistema.
- Verificador de atualizações do GitHub.
- Build Release assinado via GitHub Secrets.

package com.nerdora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddToQueue
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.StopCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nerdora.player.LibraryStore
import com.nerdora.player.MainActivity
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.data.LocalMediaRepository
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia
import com.nerdora.player.model.TechnicalInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaViewerScreen(
    activity: MainActivity,
    items: List<NerdoraMedia>,
    initialIndex: Int,
    autoplay: Boolean,
    onClose: () -> Unit,
    onEnterPictureInPicture: () -> Unit,
    onStoreChanged: () -> Unit
) {
    BackHandler(onBack = onClose)
    val context = LocalContext.current
    val pagerState = rememberPagerState(initialPage = initialIndex.coerceIn(items.indices)) { items.size }
    val current = items[pagerState.currentPage]
    var rotation by remember(current.id) { mutableFloatStateOf(0f) }
    var slideshow by remember { mutableStateOf(false) }
    var infoOpen by remember { mutableStateOf(false) }
    var playlistOpen by remember { mutableStateOf(false) }
    var favorite by remember(current.id) { mutableStateOf(LibraryStore.isFavorite(context, current.id)) }
    var videoChromeVisible by remember(current.id) { mutableStateOf(true) }
    var imageZoomed by remember(current.id) { mutableStateOf(false) }

    LaunchedEffect(current.id) {
        videoChromeVisible = true
        imageZoomed = false
        LibraryStore.recordOpened(context, current.id)
        onStoreChanged()
    }

    LaunchedEffect(slideshow, current.id) {
        if (slideshow && current.kind == MediaKind.IMAGE && items.size > 1) {
            delay(PlayerPreferences.slideshowSeconds(context) * 1000L)
            val next = (pagerState.currentPage + 1) % items.size
            pagerState.animateScrollToPage(next)
        }
    }

    Surface(Modifier.fillMaxSize(), color = Color.Black) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().weight(1f)) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    beyondViewportPageCount = 1,
                    userScrollEnabled = !(current.kind == MediaKind.IMAGE && imageZoomed)
                ) { page ->
                    val item = items[page]
                    when (item.kind) {
                        MediaKind.IMAGE -> ZoomableImage(
                            url = item.url,
                            contentDescription = item.title,
                            modifier = Modifier.fillMaxSize(),
                            rotationDegrees = if (page == pagerState.currentPage) rotation else 0f,
                            onZoomChanged = { zoomed ->
                                if (page == pagerState.currentPage) imageZoomed = zoomed
                            }
                        )
                        MediaKind.VIDEO -> if (page == pagerState.currentPage) {
                            NerdoraVideoPlayer(
                                media = item,
                                autoplay = autoplay,
                                onEnterPictureInPicture = onEnterPictureInPicture,
                                onCast = activity::openCastSettings,
                                onControlsVisibilityChanged = { visible -> videoChromeVisible = visible },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            AsyncImage(item.thumbnailUrl ?: item.url, item.title, Modifier.fillMaxSize())
                        }
                        MediaKind.AUDIO -> if (page == pagerState.currentPage) {
                            NerdoraAudioPlayer(media = item, queue = items, autoplay = autoplay, modifier = Modifier.fillMaxSize())
                        } else {
                            Box(Modifier.fillMaxSize().background(Color(0xFF160A25)), contentAlignment = Alignment.Center) {
                                Text(item.title, color = Color.White)
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = current.kind != MediaKind.VIDEO || videoChromeVisible,
                    modifier = Modifier.align(Alignment.TopCenter),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0x88000000))
                            .statusBarsPadding()
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Fechar", tint = Color.White) }
                        Text("${pagerState.currentPage + 1}/${items.size}", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        if (current.kind == MediaKind.IMAGE) {
                            IconButton(onClick = { rotation = (rotation + 90f) % 360f }) { Icon(Icons.Rounded.RotateRight, "Girar", tint = Color.White) }
                            IconButton(onClick = { slideshow = !slideshow }) {
                                Icon(if (slideshow) Icons.Rounded.StopCircle else Icons.Rounded.PlayCircle, "Apresentação", tint = if (slideshow) MaterialTheme.colorScheme.primary else Color.White)
                            }
                        }
                        IconButton(onClick = {
                            favorite = !favorite
                            LibraryStore.setFavorite(context, current.id, favorite)
                            onStoreChanged()
                        }) { Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favoritar", tint = if (favorite) MaterialTheme.colorScheme.primary else Color.White) }
                        IconButton(onClick = { shareMedia(context, listOf(current)) }) { Icon(Icons.Rounded.Share, "Compartilhar", tint = Color.White) }
                        IconButton(onClick = { infoOpen = true }) { Icon(Icons.Rounded.Info, "Informações", tint = Color.White) }
                    }
                }
            }

            Surface(color = Color(0xFF0C0910), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().heightIn(min = 112.dp).padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text(current.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        when (current.kind) {
                            MediaKind.AUDIO -> listOf(current.artist, current.album).filter { it.isNotBlank() }.joinToString(" • ")
                            else -> current.folder.ifBlank { current.description }
                        },
                        color = Color(0xFFCFC3DA), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { playlistOpen = true }) {
                            Icon(Icons.Rounded.AddToQueue, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.size(5.dp)); Text("Playlist")
                        }
                        if (current.isLocal) {
                            TextButton(onClick = {
                                LibraryStore.setHidden(context, current.id, true)
                                onStoreChanged()
                                onClose()
                            }) {
                                Icon(Icons.Rounded.Lock, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.size(5.dp)); Text("Ocultar")
                            }
                        }
                    }
                }
            }
        }
    }

    if (infoOpen) {
        TechnicalInfoDialog(media = current, onDismiss = { infoOpen = false })
    }

    if (playlistOpen) {
        PlaylistPickerDialog(
            media = current,
            onDismiss = { playlistOpen = false },
            onChanged = onStoreChanged
        )
    }
}

@Composable
private fun TechnicalInfoDialog(media: NerdoraMedia, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var info by remember(media.id) { mutableStateOf<TechnicalInfo?>(null) }
    LaunchedEffect(media.id) {
        info = withContext(Dispatchers.IO) { LocalMediaRepository.loadTechnicalInfo(context, media) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Informações da mídia") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Nome: ${media.title}")
                Text("Tipo: ${info?.mimeType?.ifBlank { media.mimeType } ?: media.mimeType}")
                Text("Tamanho: ${formatBytes(info?.sizeBytes ?: media.sizeBytes)}")
                if ((info?.width ?: media.width) > 0) Text("Resolução: ${info?.width ?: media.width} × ${info?.height ?: media.height}")
                if ((info?.durationMs ?: media.durationMs) > 0) Text("Duração: ${formatDuration(info?.durationMs ?: media.durationMs)}")
                if ((info?.bitrate ?: 0L) > 0) Text("Bitrate: ${((info?.bitrate ?: 0L) / 1000)} kbps")
                if ((info?.frameRate ?: 0f) > 0f) Text("FPS: %.1f".format(info?.frameRate ?: 0f))
                if (media.folder.isNotBlank()) Text("Pasta/álbum: ${media.folder}")
                Text("Adicionado: ${formatDate(media.dateAddedSeconds)}")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
private fun PlaylistPickerDialog(media: NerdoraMedia, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val context = LocalContext.current
    var playlists by remember { mutableStateOf(LibraryStore.playlists(context)) }
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar à playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                playlists.keys.forEach { name ->
                    Button(onClick = {
                        LibraryStore.addToPlaylist(context, name, media.id)
                        playlists = LibraryStore.playlists(context)
                        onChanged()
                    }, modifier = Modifier.fillMaxWidth()) { Text(name) }
                }
                androidx.compose.material3.OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Nova playlist") },
                    singleLine = true
                )
                TextButton(onClick = {
                    if (newName.isNotBlank()) {
                        LibraryStore.createPlaylist(context, newName)
                        LibraryStore.addToPlaylist(context, newName, media.id)
                        playlists = LibraryStore.playlists(context)
                        newName = ""
                        onChanged()
                    }
                }) { Text("Criar e adicionar") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Concluir") } }
    )
}

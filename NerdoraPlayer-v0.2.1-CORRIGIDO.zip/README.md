# Nerdora Player v0.2.1

Projeto Android nativo do Nerdora Player.

## Stack
- Kotlin
- Jetpack Compose
- AndroidX Media3 / ExoPlayer
- Coil
- Android API 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17

## Identidade
- applicationId: `com.nerdora.player`
- rootProject: `NerdoraPlayer`
- nome exibido: `Nerdora Player`

## Recursos iniciais
- player de vídeo personalizado
- play/pause e ±10 segundos
- barra de progresso
- velocidade
- seleção de limite de qualidade
- legendas
- Picture-in-Picture
- retomada de reprodução
- galeria de fotos e vídeos
- zoom, pan e rotação de imagem
- foto de perfil ampliável
- compartilhamento
- deep link `nerdora://player`
- identidade visual e ícone Nerdora Player

## Build
O projeto possui workflow em `.github/workflows/build-apk.yml` para repositórios onde os arquivos do projeto estão extraídos na raiz.

Para o método em que o projeto fica dentro de um único ZIP no repositório, use o workflow externo `nerdora-player-from-zip.yml` fornecido junto com este pacote.

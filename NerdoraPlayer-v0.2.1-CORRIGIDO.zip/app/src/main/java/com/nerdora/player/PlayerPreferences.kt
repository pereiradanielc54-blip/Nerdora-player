package com.nerdora.player

import android.content.Context

object PlayerPreferences {
    private const val PREFS = "nerdora_player_prefs"
    private const val AUTOPLAY = "autoplay"

    fun autoplay(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(AUTOPLAY, true)

    fun setAutoplay(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(AUTOPLAY, enabled)
            .apply()
    }

    fun loadPosition(context: Context, mediaKey: String): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong("position_${mediaKey.hashCode()}", 0L)

    fun savePosition(context: Context, mediaKey: String, positionMs: Long) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = "position_${mediaKey.hashCode()}"
        if (positionMs < 5_000L) {
            prefs.edit().remove(key).apply()
        } else {
            prefs.edit().putLong(key, positionMs).apply()
        }
    }

    fun clearPosition(context: Context, mediaKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove("position_${mediaKey.hashCode()}")
            .apply()
    }
}

package com.nerdora.player.data

import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

object SampleMedia {
    val items = listOf(
        NerdoraMedia(
            id = "video-1",
            kind = MediaKind.VIDEO,
            url = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            thumbnailUrl = "https://picsum.photos/seed/nerdora-video-1/1280/720",
            title = "Nerdora Player",
            description = "Player de vídeo com controles próprios, PiP, velocidade e qualidade.",
            username = "@nerdora",
            avatarUrl = "https://picsum.photos/seed/nerdora-avatar/300/300",
            likes = 2480,
            comments = 183,
            views = 18540
        ),
        NerdoraMedia(
            id = "image-1",
            kind = MediaKind.IMAGE,
            url = "https://picsum.photos/seed/nerdora-photo-1/1600/2200",
            thumbnailUrl = "https://picsum.photos/seed/nerdora-photo-1/600/800",
            title = "Arte em alta qualidade",
            description = "Toque duas vezes ou use pinça para ampliar a imagem.",
            username = "@otaku.guide",
            avatarUrl = "https://picsum.photos/seed/otaku-avatar/300/300",
            likes = 934,
            comments = 61,
            views = 7400
        ),
        NerdoraMedia(
            id = "image-2",
            kind = MediaKind.IMAGE,
            url = "https://picsum.photos/seed/nerdora-photo-2/1800/1200",
            thumbnailUrl = "https://picsum.photos/seed/nerdora-photo-2/900/600",
            title = "Galeria Nerdora",
            description = "Fotos e vídeos podem conviver na mesma galeria.",
            username = "@nerdora",
            avatarUrl = "https://picsum.photos/seed/nerdora-avatar/300/300",
            likes = 1201,
            comments = 88,
            views = 9110
        ),
        NerdoraMedia(
            id = "video-2",
            kind = MediaKind.VIDEO,
            url = "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
            thumbnailUrl = "https://picsum.photos/seed/nerdora-video-2/1280/720",
            title = "Vídeo horizontal",
            description = "Exemplo de reprodução em tela cheia dentro do visualizador.",
            username = "@anime.clips",
            avatarUrl = "https://picsum.photos/seed/anime-avatar/300/300",
            likes = 4210,
            comments = 302,
            views = 38000
        ),
        NerdoraMedia(
            id = "image-3",
            kind = MediaKind.IMAGE,
            url = "https://picsum.photos/seed/nerdora-photo-3/1400/1900",
            thumbnailUrl = "https://picsum.photos/seed/nerdora-photo-3/700/950",
            title = "Perfil ampliado",
            description = "A mesma tela pode ser usada para abrir a foto de perfil em tamanho maior.",
            username = "@kael",
            avatarUrl = "https://picsum.photos/seed/kael-avatar/300/300",
            likes = 666,
            comments = 45,
            views = 6230
        ),
        NerdoraMedia(
            id = "image-4",
            kind = MediaKind.IMAGE,
            url = "https://picsum.photos/seed/nerdora-photo-4/2000/1333",
            thumbnailUrl = "https://picsum.photos/seed/nerdora-photo-4/900/600",
            title = "Modo galeria",
            description = "Deslize horizontalmente para navegar entre as mídias.",
            username = "@nerdora",
            avatarUrl = "https://picsum.photos/seed/nerdora-avatar/300/300",
            likes = 1833,
            comments = 97,
            views = 12200
        )
    )
}

package com.nerdora.player.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.nerdora.player.MainActivity
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.data.SampleMedia
import com.nerdora.player.model.NerdoraMedia

@Composable
fun NerdoraPlayerApp(
    activity: MainActivity,
    externalMedia: NerdoraMedia?,
    onEnterPictureInPicture: () -> Unit
) {
    val media = if (externalMedia != null) listOf(externalMedia) + SampleMedia.items else SampleMedia.items
    var viewerIndex by rememberSaveable { mutableStateOf<Int?>(if (externalMedia != null) 0 else null) }
    var autoplay by rememberSaveable { mutableStateOf(PlayerPreferences.autoplay(activity)) }

    LaunchedEffect(externalMedia?.id) {
        if (externalMedia != null) viewerIndex = 0
    }

    val selected = viewerIndex
    if (selected == null) {
        MediaGalleryScreen(
            items = media,
            autoplay = autoplay,
            onAutoplayChange = { enabled ->
                autoplay = enabled
                PlayerPreferences.setAutoplay(activity, enabled)
            },
            onOpen = { viewerIndex = it }
        )
    } else {
        MediaViewerScreen(
            activity = activity,
            items = media,
            initialIndex = selected.coerceIn(media.indices),
            onClose = { viewerIndex = null },
            autoplay = autoplay,
            onEnterPictureInPicture = onEnterPictureInPicture
        )
    }
}

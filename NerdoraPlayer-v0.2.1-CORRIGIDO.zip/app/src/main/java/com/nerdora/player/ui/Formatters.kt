package com.nerdora.player.ui

fun formatDuration(ms: Long): String {
    if (ms <= 0) return "00:00"
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%02d:%02d".format(minutes, seconds)
    }
}

fun compactNumber(value: Int): String = when {
    value >= 1_000_000 -> "%.1f mi".format(value / 1_000_000f)
    value >= 1_000 -> "%.1f mil".format(value / 1_000f)
    else -> value.toString()
}

package com.nerdora.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableStateOf
import com.nerdora.player.data.SampleMedia
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia
import com.nerdora.player.ui.NerdoraPlayerApp
import com.nerdora.player.ui.NerdoraTheme

class MainActivity : ComponentActivity() {

    private val incomingMedia = mutableStateOf<NerdoraMedia?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        incomingMedia.value = parseIncomingMedia(intent)

        setContent {
            NerdoraTheme {
                NerdoraPlayerApp(
                    activity = this,
                    externalMedia = incomingMedia.value,
                    onEnterPictureInPicture = { enterNerdoraPip() }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingMedia.value = parseIncomingMedia(intent)
    }

    private fun parseIncomingMedia(intent: Intent?): NerdoraMedia? {
        if (intent == null || intent.action != Intent.ACTION_VIEW) return null

        val uri: Uri = intent.data ?: return null
        val mime = intent.type.orEmpty()
        val kind = when {
            mime.startsWith("image/") -> MediaKind.IMAGE
            mime.startsWith("video/") -> MediaKind.VIDEO
            uri.getQueryParameter("type")?.equals("image", ignoreCase = true) == true -> MediaKind.IMAGE
            else -> MediaKind.VIDEO
        }

        val resolvedUrl = if (uri.scheme == "nerdora" && uri.host == "player") {
            uri.getQueryParameter("url") ?: return null
        } else {
            uri.toString()
        }

        return NerdoraMedia(
            id = "external-${System.currentTimeMillis()}",
            kind = kind,
            url = resolvedUrl,
            thumbnailUrl = uri.getQueryParameter("thumbnail"),
            title = uri.getQueryParameter("title") ?: "Mídia Nerdora",
            description = uri.getQueryParameter("description").orEmpty(),
            username = uri.getQueryParameter("user") ?: "@nerdora"
        )
    }

    fun enterNerdoraPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    }
}

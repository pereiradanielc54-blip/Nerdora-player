package com.nerdora.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NerdoraDarkColors = darkColorScheme(
    primary = Color(0xFF8B5CF6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2E1065),
    onPrimaryContainer = Color(0xFFEDE9FE),
    secondary = Color(0xFFC084FC),
    background = Color(0xFF09070D),
    onBackground = Color(0xFFF5F3FF),
    surface = Color(0xFF120E18),
    onSurface = Color(0xFFF5F3FF),
    surfaceVariant = Color(0xFF21182D),
    onSurfaceVariant = Color(0xFFD8CDE5)
)

@Composable
fun NerdoraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NerdoraDarkColors,
        content = content
    )
}

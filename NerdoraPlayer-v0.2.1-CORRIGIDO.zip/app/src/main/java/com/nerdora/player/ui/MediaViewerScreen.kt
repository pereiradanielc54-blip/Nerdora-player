package com.nerdora.player.ui

import android.content.Intent
import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import com.nerdora.player.MainActivity
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

@Composable
fun MediaViewerScreen(
    activity: MainActivity,
    items: List<NerdoraMedia>,
    initialIndex: Int,
    onClose: () -> Unit,
    autoplay: Boolean,
    onEnterPictureInPicture: () -> Unit
) {
    BackHandler(onBack = onClose)
    val pagerState = rememberPagerState(initialPage = initialIndex) { items.size }
    val current = items[pagerState.currentPage]
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    DisposableEffect(Unit) {
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black)
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    beyondViewportPageCount = 1
                ) { page ->
                    val item = items[page]
                    when (item.kind) {
                        MediaKind.IMAGE -> ZoomableImage(
                            url = item.url,
                            contentDescription = item.title,
                            modifier = Modifier.fillMaxSize()
                        )

                        MediaKind.VIDEO -> {
                            if (page == pagerState.currentPage) {
                                NerdoraVideoPlayer(
                                    url = item.url,
                                    autoplay = autoplay,
                                    onEnterPictureInPicture = onEnterPictureInPicture,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                AsyncImage(
                                    model = item.thumbnailUrl ?: item.url,
                                    contentDescription = item.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }
                    }
                }

                ViewerTopBar(
                    title = "${pagerState.currentPage + 1} de ${items.size}",
                    onClose = onClose,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }

            if (!isLandscape) {
                MediaInfoPanel(media = current)
            }
        }
    }
}

@Composable
private fun ViewerTopBar(
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xCC09070D), Color.Transparent)
                )
            )
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Rounded.Close, contentDescription = "Fechar", tint = Color.White)
        }
        Spacer(Modifier.weight(1f))
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        Spacer(Modifier.size(48.dp))
    }
}

@Composable
private fun MediaInfoPanel(media: NerdoraMedia) {
    val context = LocalContext.current
    var liked by rememberSaveable(media.id) { mutableStateOf(false) }
    var saved by rememberSaveable(media.id) { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var avatarOpen by remember { mutableStateOf(false) }

    Surface(
        color = Color(0xFF0D0912),
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 152.dp)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NerdoraAvatar(
                    avatarUrl = media.avatarUrl,
                    username = media.username,
                    onClick = { if (media.avatarUrl != null) avatarOpen = true }
                )
                Spacer(Modifier.size(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        media.username,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    if (media.title.isNotBlank()) {
                        Text(
                            media.title,
                            color = Color(0xFFF2EAFE),
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "Mais opções", tint = Color.White)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Denunciar mídia") },
                            onClick = { menuOpen = false }
                        )
                    }
                }
            }

            if (media.description.isNotBlank()) {
                Text(
                    media.description,
                    color = Color(0xFFCFC3DA),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Action(
                    icon = if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    label = compactNumber(media.likes + if (liked) 1 else 0),
                    selected = liked,
                    onClick = { liked = !liked }
                )
                Action(
                    icon = Icons.Rounded.ChatBubbleOutline,
                    label = compactNumber(media.comments),
                    onClick = { }
                )
                Action(
                    icon = Icons.Rounded.Share,
                    label = "Compartilhar",
                    onClick = {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, media.url)
                        }
                        context.startActivity(Intent.createChooser(share, "Compartilhar mídia"))
                    }
                )
                Action(
                    icon = if (saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                    label = if (saved) "Salvo" else "Salvar",
                    selected = saved,
                    onClick = { saved = !saved }
                )
            }

            Row(
                modifier = Modifier.padding(top = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Rounded.Visibility,
                    contentDescription = null,
                    tint = Color(0xFF9D8CAB),
                    modifier = Modifier.size(15.dp)
                )
                Spacer(Modifier.size(5.dp))
                Text(
                    "${compactNumber(media.views)} visualizações",
                    color = Color(0xFF9D8CAB),
                    fontSize = 11.sp
                )
            }
        }
    }

    if (avatarOpen && media.avatarUrl != null) {
        AvatarViewerDialog(
            url = media.avatarUrl,
            username = media.username,
            onClose = { avatarOpen = false }
        )
    }
}

@Composable
private fun NerdoraAvatar(
    avatarUrl: String?,
    username: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFA855F7), Color(0xFF6D28D9), Color(0xFFC084FC))
                )
            )
            .padding(2.dp)
            .clip(CircleShape)
            .background(Color(0xFF17111F))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (avatarUrl != null) {
            AsyncImage(
                model = avatarUrl,
                contentDescription = "Foto de $username",
                modifier = Modifier.fillMaxSize().clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Text(
                username.removePrefix("@").take(1).uppercase(),
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun Action(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (selected) MaterialTheme.colorScheme.secondary else Color.White,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.size(4.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
private fun AvatarViewerDialog(
    url: String,
    username: String,
    onClose: () -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xF509070D))
        ) {
            ZoomableImage(
                url = url,
                contentDescription = "Foto de perfil de $username",
                modifier = Modifier.fillMaxSize()
            )
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(Color(0x9909070D))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, contentDescription = "Fechar foto", tint = Color.White)
                }
                Text(username, color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

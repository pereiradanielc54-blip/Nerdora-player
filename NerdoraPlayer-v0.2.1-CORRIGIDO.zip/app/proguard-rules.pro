# Nerdora Player - add release rules here if minification is enabled later.

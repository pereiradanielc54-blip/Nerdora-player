package com.nerdora.player.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nerdora.player.R
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

private enum class GallerySource { DEVICE, DEMO }
private enum class MediaFilter { ALL, IMAGE, VIDEO, AUDIO }

@Composable
fun MediaGalleryScreen(
    localItems: List<NerdoraMedia>,
    demoItems: List<NerdoraMedia>,
    hasMediaAccess: Boolean,
    photoAccess: Boolean,
    videoAccess: Boolean,
    audioAccess: Boolean,
    autoplay: Boolean,
    onAutoplayChange: (Boolean) -> Unit,
    onRequestPermissions: () -> Unit,
    onRefresh: () -> Unit,
    onOpen: (List<NerdoraMedia>, Int) -> Unit
) {
    var sourceName by rememberSaveable { mutableStateOf(GallerySource.DEVICE.name) }
    var filterName by rememberSaveable { mutableStateOf(MediaFilter.ALL.name) }
    val source = runCatching { GallerySource.valueOf(sourceName) }.getOrDefault(GallerySource.DEVICE)
    val filter = runCatching { MediaFilter.valueOf(filterName) }.getOrDefault(MediaFilter.ALL)

    val visibleItems = when (source) {
        GallerySource.DEMO -> demoItems
        GallerySource.DEVICE -> localItems.filter { item ->
            when (filter) {
                MediaFilter.ALL -> true
                MediaFilter.IMAGE -> item.kind == MediaKind.IMAGE
                MediaFilter.VIDEO -> item.kind == MediaKind.VIDEO
                MediaFilter.AUDIO -> item.kind == MediaKind.AUDIO
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF2E1065), MaterialTheme.colorScheme.background)
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 28.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.nerdora_player_mark),
                        contentDescription = "Logo Nerdora Player",
                        modifier = Modifier
                            .size(58.dp)
                            .clip(RoundedCornerShape(17.dp)),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.size(14.dp))
                    Column {
                        Text(
                            "Nerdora Player",
                            color = Color.White,
                            fontSize = 25.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Suas fotos, vídeos e músicas em um só lugar",
                            color = Color(0xFFD8CDE5),
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = source == GallerySource.DEVICE,
                        onClick = { sourceName = GallerySource.DEVICE.name },
                        label = { Text("Meu celular") },
                        leadingIcon = {
                            Icon(Icons.Rounded.PhoneAndroid, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    )
                    FilterChip(
                        selected = source == GallerySource.DEMO,
                        onClick = { sourceName = GallerySource.DEMO.name },
                        label = { Text("Demonstração") },
                        leadingIcon = {
                            Icon(Icons.Rounded.Collections, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    )
                }

                if (source == GallerySource.DEVICE) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = filter == MediaFilter.ALL,
                            onClick = { filterName = MediaFilter.ALL.name },
                            label = { Text("Tudo") }
                        )
                        FilterChip(
                            selected = filter == MediaFilter.IMAGE,
                            onClick = { filterName = MediaFilter.IMAGE.name },
                            label = { Text("Fotos") },
                            enabled = photoAccess || !hasMediaAccess
                        )
                        FilterChip(
                            selected = filter == MediaFilter.VIDEO,
                            onClick = { filterName = MediaFilter.VIDEO.name },
                            label = { Text("Vídeos") },
                            enabled = videoAccess || !hasMediaAccess
                        )
                        FilterChip(
                            selected = filter == MediaFilter.AUDIO,
                            onClick = { filterName = MediaFilter.AUDIO.name },
                            label = { Text("Músicas") },
                            enabled = audioAccess || !hasMediaAccess
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val label = if (source == GallerySource.DEVICE) {
                        "${visibleItems.size} itens encontrados"
                    } else {
                        "Galeria de demonstração"
                    }
                    Text(
                        label,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Text("Autoplay", color = Color(0xFFD8CDE5), fontSize = 12.sp)
                    Switch(checked = autoplay, onCheckedChange = onAutoplayChange)
                }
            }

            if (source == GallerySource.DEVICE && (!hasMediaAccess || visibleItems.isEmpty())) {
                EmptyDeviceLibrary(
                    hasMediaAccess = hasMediaAccess,
                    onRequestPermissions = onRequestPermissions,
                    onRefresh = onRefresh
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 145.dp),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    itemsIndexed(visibleItems, key = { _, item -> item.id }) { index, item ->
                        GalleryTile(
                            item = item,
                            onClick = { onOpen(visibleItems, index) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyDeviceLibrary(
    hasMediaAccess: Boolean,
    onRequestPermissions: () -> Unit,
    onRefresh: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                Icons.Rounded.PhoneAndroid,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(54.dp)
            )
            Text(
                if (hasMediaAccess) "Nenhuma mídia encontrada" else "Acesse a mídia do seu celular",
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                if (hasMediaAccess) {
                    "Se você acabou de adicionar arquivos, toque em Atualizar."
                } else {
                    "O Nerdora Player precisa da sua autorização para mostrar fotos, vídeos e músicas armazenados no aparelho."
                },
                color = Color(0xFFCFC3DA),
                fontSize = 13.sp
            )
            if (!hasMediaAccess) {
                Button(onClick = onRequestPermissions) {
                    Text("Permitir acesso")
                }
            } else {
                OutlinedButton(onClick = onRefresh) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Atualizar")
                }
            }
        }
    }
}

@Composable
private fun GalleryTile(item: NerdoraMedia, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .background(Color(0xFF17111F))
            .clickable(onClick = onClick)
    ) {
        if (item.kind == MediaKind.AUDIO && item.thumbnailUrl == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF4C1D95), Color(0xFF140A20))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.LibraryMusic,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(62.dp)
                )
            }
        } else {
            AsyncImage(
                model = item.thumbnailUrl ?: item.url,
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent, Color(0xCC09070D))
                    )
                )
        )

        when (item.kind) {
            MediaKind.VIDEO -> {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Reproduzir", tint = Color.White)
                }
            }
            MediaKind.AUDIO -> {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(0xAA5B21B6)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.LibraryMusic,
                        contentDescription = "Música",
                        tint = Color.White,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
            MediaKind.IMAGE -> Unit
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
        ) {
            Text(
                item.title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                if (item.kind == MediaKind.AUDIO) item.description else item.username,
                color = Color(0xFFD8CDE5),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

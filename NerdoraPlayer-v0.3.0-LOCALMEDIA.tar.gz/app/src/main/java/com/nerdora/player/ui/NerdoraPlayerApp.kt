package com.nerdora.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.nerdora.player.MainActivity
import com.nerdora.player.MediaPermissions
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.data.LocalMediaRepository
import com.nerdora.player.data.SampleMedia
import com.nerdora.player.model.NerdoraMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun NerdoraPlayerApp(
    activity: MainActivity,
    externalMedia: NerdoraMedia?,
    onEnterPictureInPicture: () -> Unit
) {
    var viewerItems by remember { mutableStateOf<List<NerdoraMedia>>(emptyList()) }
    var viewerIndex by rememberSaveable { mutableStateOf<Int?>(if (externalMedia != null) 0 else null) }
    var autoplay by rememberSaveable { mutableStateOf(PlayerPreferences.autoplay(activity)) }
    var localMedia by remember { mutableStateOf<List<NerdoraMedia>>(emptyList()) }
    var permissionEpoch by remember { mutableIntStateOf(0) }
    var hasMediaAccess by remember { mutableStateOf(MediaPermissions.hasAnyAccess(activity)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hasMediaAccess = MediaPermissions.hasAnyAccess(activity)
        permissionEpoch++
    }

    LaunchedEffect(permissionEpoch, hasMediaAccess) {
        localMedia = withContext(Dispatchers.IO) {
            LocalMediaRepository.loadAll(activity)
        }
    }

    LaunchedEffect(externalMedia?.id) {
        if (externalMedia != null) {
            viewerItems = listOf(externalMedia)
            viewerIndex = 0
        }
    }

    val selected = viewerIndex
    if (selected == null) {
        MediaGalleryScreen(
            localItems = localMedia,
            demoItems = SampleMedia.items,
            hasMediaAccess = hasMediaAccess,
            photoAccess = MediaPermissions.hasPhotoAccess(activity),
            videoAccess = MediaPermissions.hasVideoAccess(activity),
            audioAccess = MediaPermissions.hasAudioAccess(activity),
            autoplay = autoplay,
            onAutoplayChange = { enabled ->
                autoplay = enabled
                PlayerPreferences.setAutoplay(activity, enabled)
            },
            onRequestPermissions = {
                permissionLauncher.launch(MediaPermissions.permissionsToRequest())
            },
            onRefresh = {
                hasMediaAccess = MediaPermissions.hasAnyAccess(activity)
                permissionEpoch++
            },
            onOpen = { items, index ->
                viewerItems = items
                viewerIndex = index
            }
        )
    } else {
        val items = viewerItems.ifEmpty {
            externalMedia?.let { listOf(it) } ?: SampleMedia.items
        }
        MediaViewerScreen(
            activity = activity,
            items = items,
            initialIndex = selected.coerceIn(items.indices),
            onClose = { viewerIndex = null },
            autoplay = autoplay,
            onEnterPictureInPicture = onEnterPictureInPicture
        )
    }
}

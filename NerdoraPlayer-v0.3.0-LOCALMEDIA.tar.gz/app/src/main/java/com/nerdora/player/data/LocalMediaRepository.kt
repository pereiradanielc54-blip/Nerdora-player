package com.nerdora.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

object LocalMediaRepository {

    fun loadAll(context: Context): List<NerdoraMedia> {
        val result = mutableListOf<NerdoraMedia>()
        result += runCatching { loadImages(context) }.getOrDefault(emptyList())
        result += runCatching { loadVideos(context) }.getOrDefault(emptyList())
        result += runCatching { loadAudio(context) }.getOrDefault(emptyList())
        return result.sortedByDescending { it.dateAddedSeconds }
    }

    private fun loadImages(context: Context): List<NerdoraMedia> {
        val items = mutableListOf<NerdoraMedia>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED
        )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val name = cursor.getString(nameColumn) ?: "Foto"
                val dateAdded = cursor.getLong(dateColumn)
                val uri = ContentUris.withAppendedId(collection, id)

                items += NerdoraMedia(
                    id = "local-image-$id",
                    kind = MediaKind.IMAGE,
                    url = uri.toString(),
                    thumbnailUrl = uri.toString(),
                    title = name,
                    description = "Foto do seu dispositivo",
                    username = "Meu celular",
                    dateAddedSeconds = dateAdded
                )
            }
        }
        return items
    }

    private fun loadVideos(context: Context): List<NerdoraMedia> {
        val items = mutableListOf<NerdoraMedia>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DURATION
        )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val name = cursor.getString(nameColumn) ?: "Vídeo"
                val dateAdded = cursor.getLong(dateColumn)
                val duration = cursor.getLong(durationColumn)
                val uri = ContentUris.withAppendedId(collection, id)

                items += NerdoraMedia(
                    id = "local-video-$id",
                    kind = MediaKind.VIDEO,
                    url = uri.toString(),
                    thumbnailUrl = uri.toString(),
                    title = name,
                    description = "Vídeo do seu dispositivo",
                    username = "Meu celular",
                    durationMs = duration,
                    dateAddedSeconds = dateAdded
                )
            }
        }
        return items
    }

    private fun loadAudio(context: Context): List<NerdoraMedia> {
        val items = mutableListOf<NerdoraMedia>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        context.contentResolver.query(
            collection,
            projection,
            selection,
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val displayNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val displayName = cursor.getString(displayNameColumn) ?: "Música"
                val title = cursor.getString(titleColumn)?.takeIf { it.isNotBlank() } ?: displayName
                val artist = cursor.getString(artistColumn)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                    ?: "Artista desconhecido"
                val albumId = cursor.getLong(albumIdColumn)
                val dateAdded = cursor.getLong(dateColumn)
                val duration = cursor.getLong(durationColumn)
                val uri = ContentUris.withAppendedId(collection, id)
                val albumArt = if (albumId > 0) {
                    ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId).toString()
                } else null

                items += NerdoraMedia(
                    id = "local-audio-$id",
                    kind = MediaKind.AUDIO,
                    url = uri.toString(),
                    thumbnailUrl = albumArt,
                    title = title,
                    description = artist,
                    username = "Músicas do aparelho",
                    durationMs = duration,
                    dateAddedSeconds = dateAdded
                )
            }
        }
        return items
    }
}

# Nerdora Player v0.3.0

Aplicativo Android nativo do Nerdora Player, com acesso à biblioteca de mídia local do aparelho.

## Novidades da v0.3.0
- acesso às fotos do celular via Android MediaStore;
- acesso aos vídeos do celular via Android MediaStore;
- acesso às músicas do celular via Android MediaStore;
- permissões modernas para Android 13+ (`READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`);
- suporte ao acesso parcial de fotos e vídeos no Android 14+;
- compatibilidade com Android 12L e anteriores usando `READ_EXTERNAL_STORAGE`;
- aba `Meu celular` com filtros Tudo, Fotos, Vídeos e Músicas;
- player dedicado para músicas;
- reprodução de vídeos locais pelo ExoPlayer;
- visualização e zoom de fotos locais;
- compartilhamento de mídia local por URI;
- mantém a galeria de demonstração separada.

## Stack
- Kotlin
- Jetpack Compose
- AndroidX Media3 / ExoPlayer
- Coil
- MediaStore
- Android API 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17

## Identidade
- applicationId: `com.nerdora.player`
- rootProject: `NerdoraPlayer`
- nome exibido: `Nerdora Player`
- versionName: `0.3.0`
- versionCode: `6`

## Como funciona o acesso às mídias
Na primeira vez que o usuário abrir a aba `Meu celular`, o app mostra o botão `Permitir acesso`.
O Android exibe a tela oficial de permissões. O usuário escolhe quais tipos de mídia deseja liberar.

No Android 14 ou superior, o usuário também pode liberar apenas fotos e vídeos selecionados.

O Nerdora Player não copia a biblioteca para dentro do aplicativo: ele lê os itens autorizados através do MediaStore do próprio Android.

## Recursos mantidos
- player de vídeo personalizado;
- play/pause e ±10 segundos;
- barra de progresso;
- velocidade;
- seleção de limite de qualidade;
- legendas;
- Picture-in-Picture para vídeos;
- retomada de reprodução;
- zoom, pan e rotação de imagens;
- foto de perfil ampliável;
- compartilhamento;
- deep link `nerdora://player`;
- identidade visual e ícone Nerdora Player.

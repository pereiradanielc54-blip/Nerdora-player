# Nerdora Player v0.5.0 — Pro Media

Versão final do Nerdora Player independente antes de ser vinculado ao app principal Nerdora.

## Destaques

- Kotlin + Jetpack Compose + Android Media3/ExoPlayer.
- Fotos, vídeos e músicas locais via MediaStore.
- Índice SQLite local para carregamento rápido da biblioteca.
- Home inteligente com continuar assistindo, recentes e favoritos.
- Busca por nome, artista, álbum e pasta; filtros e ordenação.
- Grade compacta/normal/grande.
- Pastas/álbuns, playlists renomeáveis/duplicáveis e seleção múltipla.
- Favoritos, histórico, retomada de reprodução e lixeira lógica.
- Player de vídeo com auto-hide em 4 s, brilho/volume por gesto, duplo toque, PiP, bloqueio, legenda externa, Fit/Zoom/Fill persistente e velocidade persistente.
- Fotos com swipe, zoom, rotação e slideshow.
- Música em segundo plano com MediaSession, tela bloqueada/notificação, fila visual, shuffle/repeat, timer e letras `.lrc` escolhidas pelo usuário.
- Mini player persistente com swipe lateral e botão fechar.
- Área oculta protegida por biometria/credencial do aparelho.
- Backup/restauração em JSON.
- Diagnóstico de codecs e informações do aparelho.
- Abrir mídia por URL HTTP/HTTPS para fontes autorizadas compatíveis.
- Tema Nerdora / AMOLED, cores de destaque e opção de reduzir animações.
- Onboarding e changelog internos.
- Verificação de atualização via GitHub Releases.
- Estrutura de APK Release assinado via GitHub Secrets.

## Build

Requisitos do projeto:

- compileSdk / targetSdk: 35
- Java: 17
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3

Use o workflow `nerdora-player-build-v050.yml` fornecido junto com o pacote. Ele compila um APK debug e, quando os Secrets de assinatura existem, também um APK release assinado.

## Assinatura permanente

Configure no GitHub:

- `NERDORA_KEYSTORE_BASE64`
- `NERDORA_KEYSTORE_PASSWORD`
- `NERDORA_KEY_ALIAS`
- `NERDORA_KEY_PASSWORD`

Nunca perca o `.jks` original nem suas senhas: a mesma assinatura é necessária para atualizar o APK já instalado.

## Integração com o Nerdora

Consulte `INTEGRATION.md`. A base aceita `ACTION_VIEW`, `content://`, arquivos de áudio/vídeo/imagem e deep link do tipo:

`nerdora://player?url=https://servidor/video.m3u8&type=video&title=Titulo`

## Escopo

Esta versão não tenta extrair vídeos protegidos de plataformas como YouTube e não inclui o projeto Nerdora Cinema. O recurso de URL é para mídia direta/autorizada.

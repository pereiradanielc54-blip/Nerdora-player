package com.nerdora.player.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.R
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

@Composable
fun HomeScreen(
    items: List<NerdoraMedia>,
    demoItems: List<NerdoraMedia>,
    hasMediaAccess: Boolean,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    hiddenCount: Int,
    positionFor: (NerdoraMedia) -> Long,
    onRequestPermissions: () -> Unit,
    onOpenItems: (List<NerdoraMedia>, Int) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenFolders: () -> Unit,
    onOpenFavorites: () -> Unit,
    onOpenPrivate: () -> Unit,
    onOpenLink: () -> Unit
) {
    val visible = items
    val byId = visible.associateBy { it.id }
    val recent = recentIds.mapNotNull(byId::get).take(12)
    val favorites = visible.filter { favoriteIds.contains(it.id) }.take(12)
    val continueItems = visible.filter { media ->
        val p = positionFor(media)
        (media.kind == MediaKind.VIDEO || media.kind == MediaKind.AUDIO) &&
            p > 5_000L && (media.durationMs <= 0L || p < media.durationMs - 5_000L)
    }.take(12)
    val videos = visible.filter { it.kind == MediaKind.VIDEO }.take(12)
    val photos = visible.filter { it.kind == MediaKind.IMAGE }.take(12)
    val music = visible.filter { it.kind == MediaKind.AUDIO }.take(12)

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF3B0C72), MaterialTheme.colorScheme.background)
                            )
                        )
                        .padding(start = 18.dp, end = 18.dp, top = 28.dp, bottom = 18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.nerdora_player_mark),
                            contentDescription = "Nerdora Player",
                            modifier = Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(Modifier.size(14.dp))
                        Column {
                            Text("Nerdora Player", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            Text("Sua central de mídia", color = Color(0xFFE4D7F5), fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickAction("Biblioteca", Icons.Rounded.PermMedia, Modifier.weight(1f), onOpenLibrary)
                        QuickAction("Pastas", Icons.Rounded.Folder, Modifier.weight(1f), onOpenFolders)
                        QuickAction("Favoritos", Icons.Rounded.Favorite, Modifier.weight(1f), onOpenFavorites)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickAction("Abrir link", Icons.Rounded.PlayArrow, Modifier.weight(1f), onOpenLink)
                        Box(Modifier.weight(2f))
                    }
                    if (hiddenCount > 0) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x331F102A))
                                .clickable(onClick = onOpenPrivate)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Lock, null, tint = Color(0xFFD8B4FE))
                            Spacer(Modifier.size(8.dp))
                            Text("$hiddenCount mídia(s) oculta(s)", color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            if (!hasMediaAccess) {
                item {
                    Box(Modifier.fillMaxWidth().padding(18.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.PermMedia, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Permita o acesso às suas mídias", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                            Text("Fotos, vídeos e músicas ficam no aparelho; o Nerdora apenas lê sua biblioteca.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = onRequestPermissions) { Text("Permitir acesso") }
                        }
                    }
                }
            }

            if (continueItems.isNotEmpty()) item {
                MediaHorizontalSection(
                    title = "Continuar assistindo",
                    subtitle = "Retome do ponto onde parou",
                    items = continueItems,
                    positionFor = positionFor,
                    onOpenItems = onOpenItems
                )
            }
            if (recent.isNotEmpty()) item {
                MediaHorizontalSection("Reproduzidos recentemente", null, recent, positionFor, onOpenItems)
            }
            if (favorites.isNotEmpty()) item {
                MediaHorizontalSection("Favoritos", null, favorites, positionFor, onOpenItems, action = "Ver todos", onAction = onOpenFavorites)
            }
            if (videos.isNotEmpty()) item {
                MediaHorizontalSection("Vídeos", "Seus vídeos locais", videos, positionFor, onOpenItems, action = "Biblioteca", onAction = onOpenLibrary)
            }
            if (photos.isNotEmpty()) item {
                MediaHorizontalSection("Fotos", null, photos, positionFor, onOpenItems, action = "Biblioteca", onAction = onOpenLibrary)
            }
            if (music.isNotEmpty()) item {
                MediaHorizontalSection("Músicas", "Áudio com reprodução em segundo plano", music, positionFor, onOpenItems, action = "Biblioteca", onAction = onOpenLibrary)
            }
            if (visible.isEmpty()) item {
                MediaHorizontalSection("Demonstração Nerdora", "Exemplos online para testar o player", demoItems, { 0L }, onOpenItems)
            }
            item { Spacer(Modifier.height(100.dp)) }
        }
    }
}

@Composable
private fun QuickAction(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x332A123E))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(19.dp))
        Spacer(Modifier.size(6.dp))
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MediaHorizontalSection(
    title: String,
    subtitle: String?,
    items: List<NerdoraMedia>,
    positionFor: (NerdoraMedia) -> Long,
    onOpenItems: (List<NerdoraMedia>, Int) -> Unit,
    action: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column {
        SectionTitle(title, subtitle, action, onAction)
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items, key = { it.id }) { media ->
                val index = items.indexOfFirst { it.id == media.id }.coerceAtLeast(0)
                val pos = positionFor(media)
                val progress = if (media.durationMs > 0L) pos.toFloat() / media.durationMs.toFloat() else 0f
                MediaCard(
                    media = media,
                    modifier = Modifier.size(width = 150.dp, height = 190.dp),
                    progress = progress,
                    onClick = { onOpenItems(items, index) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

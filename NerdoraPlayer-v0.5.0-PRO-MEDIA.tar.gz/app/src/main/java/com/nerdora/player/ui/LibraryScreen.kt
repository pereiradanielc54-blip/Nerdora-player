package com.nerdora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.model.LibraryFilter
import com.nerdora.player.model.LibrarySort
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

@Composable
fun LibraryScreen(
    items: List<NerdoraMedia>,
    favoriteIds: Set<String>,
    initialFavoritesOnly: Boolean = false,
    onOpenItems: (List<NerdoraMedia>, Int) -> Unit,
    onRefresh: () -> Unit,
    onFavorite: (String, Boolean) -> Unit,
    onHide: (String, Boolean) -> Unit,
    onTrash: (String) -> Unit,
    onShare: (List<NerdoraMedia>) -> Unit
) {
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var filterName by rememberSaveable { mutableStateOf(LibraryFilter.ALL.name) }
    var sortName by rememberSaveable { mutableStateOf(LibrarySort.NEWEST.name) }
    var favoritesOnly by rememberSaveable { mutableStateOf(initialFavoritesOnly) }
    var sortMenu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var gridSize by remember { mutableStateOf(PlayerPreferences.gridSize(context)) }

    val filter = runCatching { LibraryFilter.valueOf(filterName) }.getOrDefault(LibraryFilter.ALL)
    val sort = runCatching { LibrarySort.valueOf(sortName) }.getOrDefault(LibrarySort.NEWEST)
    val filtered = sortMedia(
        items.filter { media ->
            val kindOk = when (filter) {
                LibraryFilter.ALL -> true
                LibraryFilter.IMAGE -> media.kind == MediaKind.IMAGE
                LibraryFilter.VIDEO -> media.kind == MediaKind.VIDEO
                LibraryFilter.AUDIO -> media.kind == MediaKind.AUDIO
            }
            val q = query.trim().lowercase()
            val searchOk = q.isBlank() || listOf(media.title, media.artist, media.album, media.folder)
                .any { it.lowercase().contains(q) }
            val favOk = !favoritesOnly || favoriteIds.contains(media.id)
            kindOk && searchOk && favOk
        },
        sort
    )

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            if (selected.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Rounded.Close, "Cancelar") }
                    Text("${selected.size} selecionado(s)", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    IconButton(onClick = {
                        selected.forEach { id -> onFavorite(id, true) }
                        selected = emptySet()
                    }) { Icon(Icons.Rounded.Favorite, "Favoritar") }
                    IconButton(onClick = {
                        onShare(filtered.filter { selected.contains(it.id) })
                        selected = emptySet()
                    }) { Icon(Icons.Rounded.Share, "Compartilhar") }
                    IconButton(onClick = {
                        selected.forEach { id -> onHide(id, true) }
                        selected = emptySet()
                    }) { Icon(Icons.Rounded.Lock, "Ocultar") }
                    IconButton(onClick = {
                        selected.forEach(onTrash)
                        selected = emptySet()
                    }) { Icon(Icons.Rounded.Delete, "Mover para lixeira do Nerdora") }
                }
            } else {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Biblioteca", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, "Atualizar") }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Rounded.Sort, "Ordenar") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                LibrarySort.entries.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.label) },
                                        onClick = { sortName = option.name; sortMenu = false }
                                    )
                                }
                            }
                        }
                    }
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Rounded.Search, null) },
                        placeholder = { Text("Buscar músicas, vídeos e fotos...") }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LibraryFilter.entries.forEach { option ->
                            FilterChip(
                                selected = filter == option,
                                onClick = { filterName = option.name },
                                label = { Text(option.label) }
                            )
                        }
                        FilterChip(
                            selected = favoritesOnly,
                            onClick = { favoritesOnly = !favoritesOnly },
                            label = { Text("Favoritos") },
                            leadingIcon = { Icon(Icons.Rounded.Favorite, null, modifier = Modifier.size(17.dp)) }
                        )
                        listOf(0 to "Compacta", 1 to "Normal", 2 to "Grande").forEach { (value, label) ->
                            FilterChip(
                                selected = gridSize == value,
                                onClick = {
                                    gridSize = value
                                    PlayerPreferences.setGridSize(context, value)
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                    Text(
                        "${filtered.size} itens • ${sort.label}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }

            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhuma mídia encontrada", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(when (gridSize) { 0 -> 112.dp; 2 -> 180.dp; else -> 145.dp }),
                    modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    itemsIndexed(filtered, key = { _, item -> item.id }) { index, item ->
                        MediaCard(
                            media = item,
                            modifier = Modifier.fillMaxWidth().height(205.dp),
                            selected = selected.contains(item.id),
                            onClick = {
                                if (selected.isNotEmpty()) {
                                    selected = if (selected.contains(item.id)) selected - item.id else selected + item.id
                                } else onOpenItems(filtered, index)
                            },
                            onLongClick = {
                                selected = if (selected.contains(item.id)) selected - item.id else selected + item.id
                            }
                        )
                    }
                }
            }
        }
    }
}

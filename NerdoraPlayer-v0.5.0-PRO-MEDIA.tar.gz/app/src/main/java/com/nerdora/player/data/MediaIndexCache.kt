package com.nerdora.player.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

/**
 * Pequeno índice local para abrir a biblioteca instantaneamente.
 * Os arquivos continuam no MediaStore; o banco guarda apenas metadados e URIs.
 */
object MediaIndexCache {
    private const val DB_NAME = "nerdora_media_index.db"
    private const val DB_VERSION = 1
    private const val TABLE = "media"

    private class Helper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE $TABLE (
                    id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    url TEXT NOT NULL,
                    thumbnailUrl TEXT,
                    title TEXT,
                    description TEXT,
                    username TEXT,
                    avatarUrl TEXT,
                    durationMs INTEGER,
                    dateAddedSeconds INTEGER,
                    dateModifiedSeconds INTEGER,
                    folder TEXT,
                    artist TEXT,
                    album TEXT,
                    mimeType TEXT,
                    sizeBytes INTEGER,
                    width INTEGER,
                    height INTEGER
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX media_date_idx ON $TABLE(dateAddedSeconds DESC)")
            db.execSQL("CREATE INDEX media_kind_idx ON $TABLE(kind)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE")
            onCreate(db)
        }
    }

    fun read(context: Context): List<NerdoraMedia> {
        val db = Helper(context.applicationContext).readableDatabase
        val result = mutableListOf<NerdoraMedia>()
        db.query(TABLE, null, null, null, null, null, "dateAddedSeconds DESC").use { c ->
            val id = c.getColumnIndexOrThrow("id")
            val kind = c.getColumnIndexOrThrow("kind")
            val url = c.getColumnIndexOrThrow("url")
            val thumb = c.getColumnIndexOrThrow("thumbnailUrl")
            val title = c.getColumnIndexOrThrow("title")
            val description = c.getColumnIndexOrThrow("description")
            val username = c.getColumnIndexOrThrow("username")
            val avatar = c.getColumnIndexOrThrow("avatarUrl")
            val duration = c.getColumnIndexOrThrow("durationMs")
            val added = c.getColumnIndexOrThrow("dateAddedSeconds")
            val modified = c.getColumnIndexOrThrow("dateModifiedSeconds")
            val folder = c.getColumnIndexOrThrow("folder")
            val artist = c.getColumnIndexOrThrow("artist")
            val album = c.getColumnIndexOrThrow("album")
            val mime = c.getColumnIndexOrThrow("mimeType")
            val size = c.getColumnIndexOrThrow("sizeBytes")
            val width = c.getColumnIndexOrThrow("width")
            val height = c.getColumnIndexOrThrow("height")
            while (c.moveToNext()) {
                val mediaKind = runCatching { MediaKind.valueOf(c.getString(kind)) }.getOrDefault(MediaKind.VIDEO)
                result += NerdoraMedia(
                    id = c.getString(id),
                    kind = mediaKind,
                    url = c.getString(url),
                    thumbnailUrl = c.getString(thumb),
                    title = c.getString(title).orEmpty(),
                    description = c.getString(description).orEmpty(),
                    username = c.getString(username).orEmpty(),
                    avatarUrl = c.getString(avatar),
                    durationMs = c.getLong(duration),
                    dateAddedSeconds = c.getLong(added),
                    dateModifiedSeconds = c.getLong(modified),
                    folder = c.getString(folder).orEmpty(),
                    artist = c.getString(artist).orEmpty(),
                    album = c.getString(album).orEmpty(),
                    mimeType = c.getString(mime).orEmpty(),
                    sizeBytes = c.getLong(size),
                    width = c.getInt(width),
                    height = c.getInt(height)
                )
            }
        }
        db.close()
        return result
    }

    fun replace(context: Context, items: List<NerdoraMedia>) {
        val helper = Helper(context.applicationContext)
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            db.delete(TABLE, null, null)
            items.forEach { media ->
                val values = ContentValues().apply {
                    put("id", media.id)
                    put("kind", media.kind.name)
                    put("url", media.url)
                    put("thumbnailUrl", media.thumbnailUrl)
                    put("title", media.title)
                    put("description", media.description)
                    put("username", media.username)
                    put("avatarUrl", media.avatarUrl)
                    put("durationMs", media.durationMs)
                    put("dateAddedSeconds", media.dateAddedSeconds)
                    put("dateModifiedSeconds", media.dateModifiedSeconds)
                    put("folder", media.folder)
                    put("artist", media.artist)
                    put("album", media.album)
                    put("mimeType", media.mimeType)
                    put("sizeBytes", media.sizeBytes)
                    put("width", media.width)
                    put("height", media.height)
                }
                db.insertWithOnConflict(TABLE, null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
            db.close()
            helper.close()
        }
    }

    fun clear(context: Context) {
        val helper = Helper(context.applicationContext)
        helper.writableDatabase.use { it.delete(TABLE, null, null) }
        helper.close()
    }
}

package com.nerdora.player.ui

import android.media.MediaCodecList
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nerdora.player.BuildConfig

@Composable
fun DiagnosticsScreen(onBack: () -> Unit) {
    val codecSummary = remember {
        runCatching {
            val infos = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.filterNot { it.isEncoder }
            val types = infos.flatMap { it.supportedTypes.toList() }.map { it.lowercase() }.distinct().sorted()
            val video = types.filter { it.startsWith("video/") }
            val audio = types.filter { it.startsWith("audio/") }
            Pair(video, audio)
        }.getOrDefault(Pair(emptyList(), emptyList()))
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Voltar") }
                Text("Diagnóstico", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Text("Informações úteis para identificar problemas de reprodução.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Spacer(Modifier.size(16.dp))

            DiagnosticRow("Nerdora Player", BuildConfig.VERSION_NAME)
            DiagnosticRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            DiagnosticRow("Dispositivo", "${Build.MANUFACTURER} ${Build.MODEL}")
            DiagnosticRow("Arquiteturas", Build.SUPPORTED_ABIS.joinToString())
            DiagnosticRow("App ID", BuildConfig.APPLICATION_ID)
            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.size(8.dp))
                Text("Codecs de vídeo", fontWeight = FontWeight.Bold)
            }
            Text(codecSummary.first.joinToString("\n").ifBlank { "Nenhum codec informado pelo sistema." }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Codecs de áudio", fontWeight = FontWeight.Bold)
            Text(codecSummary.second.joinToString("\n").ifBlank { "Nenhum codec informado pelo sistema." }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.size(90.dp))
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.42f))
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.weight(0.58f))
    }
}

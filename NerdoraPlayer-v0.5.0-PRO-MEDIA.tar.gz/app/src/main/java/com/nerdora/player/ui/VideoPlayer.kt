package com.nerdora.player.ui

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.data.LocalMediaRepository
import com.nerdora.player.model.NerdoraMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NerdoraVideoPlayer(
    media: NerdoraMedia,
    autoplay: Boolean,
    onEnterPictureInPicture: () -> Unit,
    onCast: () -> Unit,
    onControlsVisibilityChanged: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val seekMs = remember { PlayerPreferences.seekSeconds(context) * 1000L }
    var locked by remember(media.id) { mutableStateOf(false) }
    var resizeMode by remember(media.id) {
        mutableStateOf(
            when (PlayerPreferences.videoResizeMode(context)) {
                1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        )
    }
    var playbackSpeed by remember(media.id) { mutableFloatStateOf(PlayerPreferences.videoSpeed(context)) }
    var error by remember(media.id) { mutableStateOf<String?>(null) }
    var externalSubtitle by remember(media.id) { mutableStateOf<Uri?>(null) }
    var autoSubtitle by remember(media.id) { mutableStateOf<Uri?>(null) }
    var brightness by remember { mutableFloatStateOf(activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f) }
    var controlsVisible by remember(media.id) { mutableStateOf(true) }
    var settingsOpen by remember(media.id) { mutableStateOf(false) }
    var playerView by remember(media.id) { mutableStateOf<PlayerView?>(null) }

    fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible
        onControlsVisibilityChanged(visible)
    }

    fun showControls() {
        if (!locked) {
            playerView?.showController()
            setControlsVisible(true)
        }
    }

    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            externalSubtitle = uri
            showControls()
        }
    }

    val player = remember(media.id) {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = autoplay
            addListener(object : Player.Listener {
                override fun onPlayerError(playerError: PlaybackException) {
                    error = playerError.errorCodeName
                }
            })
        }
    }

    LaunchedEffect(media.id) {
        setControlsVisible(true)
        autoSubtitle = withContext(Dispatchers.IO) { LocalMediaRepository.findMatchingSubtitle(context, media) }
    }

    LaunchedEffect(media.id, externalSubtitle, autoSubtitle) {
        val currentPosition = player.currentPosition.coerceAtLeast(0L)
        val subtitle = externalSubtitle ?: autoSubtitle
        val mediaItem = MediaItem.Builder()
            .setUri(media.url)
            .apply {
                if (subtitle != null) {
                    val subtitleMime = if (subtitle.toString().lowercase().endsWith(".vtt")) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
                    setSubtitleConfigurations(
                        listOf(
                            MediaItem.SubtitleConfiguration.Builder(subtitle)
                                .setMimeType(subtitleMime)
                                .setLanguage("pt")
                                .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                                .build()
                        )
                    )
                }
            }
            .build()
        player.setMediaItem(mediaItem)
        player.prepare()
        player.setPlaybackSpeed(playbackSpeed)
        val saved = if (PlayerPreferences.resumePlayback(context)) PlayerPreferences.loadPosition(context, media.url) else 0L
        player.seekTo(if (currentPosition > 0L) currentPosition else saved)
        if (autoplay) player.play()
    }

    LaunchedEffect(player) {
        while (true) {
            delay(2_000L)
            val pos = player.currentPosition.coerceAtLeast(0L)
            val dur = player.duration
            if (dur > 0L && pos >= dur - 5_000L) PlayerPreferences.clearPosition(context, media.url)
            else if (pos > 5_000L) PlayerPreferences.savePosition(context, media.url, pos)
        }
    }

    DisposableEffect(player) {
        onDispose {
            val pos = player.currentPosition.coerceAtLeast(0L)
            val dur = player.duration
            if (dur > 0L && pos >= dur - 5_000L) PlayerPreferences.clearPosition(context, media.url)
            else PlayerPreferences.savePosition(context, media.url, pos)
            player.release()
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    playerView = this
                    this.player = player
                    useController = true
                    controllerAutoShow = true
                    controllerHideOnTouch = true
                    controllerShowTimeoutMs = 4_000
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setControllerVisibilityListener(
                        PlayerView.ControllerVisibilityListener { visibility ->
                            setControlsVisible(visibility == View.VISIBLE)
                        }
                    )
                    showController()
                }
            },
            update = { view ->
                playerView = view
                view.player = player
                view.useController = !locked
                view.resizeMode = resizeMode
                view.controllerShowTimeoutMs = 4_000
                if (locked) {
                    view.hideController()
                    setControlsVisible(false)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!locked) {
            GestureZone(
                modifier = Modifier.align(Alignment.CenterStart).fillMaxHeight().width(92.dp),
                onTap = ::showControls,
                onDoubleTap = {
                    player.seekTo((player.currentPosition - seekMs).coerceAtLeast(0L))
                    showControls()
                },
                onVerticalDrag = { delta ->
                    val change = -delta / 900f
                    brightness = (brightness + change).coerceIn(0.05f, 1f)
                    activity?.window?.attributes = activity?.window?.attributes?.apply { screenBrightness = brightness }
                    showControls()
                }
            )
            GestureZone(
                modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(92.dp),
                onTap = ::showControls,
                onDoubleTap = {
                    player.seekTo((player.currentPosition + seekMs).coerceAtMost(player.duration.takeIf { it > 0 } ?: Long.MAX_VALUE))
                    showControls()
                },
                onVerticalDrag = { delta ->
                    val direction = if (delta < 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0)
                    showControls()
                }
            )
        }

        if (controlsVisible && !locked) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 12.dp, bottom = 82.dp)
                    .background(Color(0xB3120E18), CircleShape)
            ) {
                IconButton(onClick = {
                    settingsOpen = true
                    showControls()
                }) {
                    Icon(Icons.Rounded.Settings, "Configurações do vídeo", tint = Color.White)
                }
            }
        }

        if (locked) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(14.dp)
                    .background(Color(0xB3120E18), CircleShape)
            ) {
                IconButton(onClick = {
                    locked = false
                    playerView?.useController = true
                    showControls()
                }) {
                    Icon(Icons.Rounded.LockOpen, "Desbloquear controles", tint = Color.White)
                }
            }
        }

        if (error != null) {
            Text(
                "Não foi possível reproduzir este vídeo ($error). O formato/codec pode não ser suportado neste aparelho.",
                color = Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xCC7F1D1D)).padding(12.dp)
            )
        }
    }

    if (settingsOpen) {
        ModalBottomSheet(
            onDismissRequest = {
                settingsOpen = false
                showControls()
            },
            containerColor = Color(0xFF17111F),
            contentColor = Color.White
        ) {
            Column(Modifier.fillMaxWidth()) {
                Text(
                    "Configurações do vídeo",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
                Text(
                    "Os controles desaparecem automaticamente após 4 segundos sem interação.",
                    color = Color(0xFFCFC3DA),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
                Spacer(Modifier.height(6.dp))
                HorizontalDivider(color = Color(0xFF34293F))

                VideoSettingItem(
                    title = "Ajuste de tela",
                    subtitle = when (resizeMode) {
                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
                        AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Preencher"
                        else -> "Ajustar"
                    },
                    icon = { Icon(Icons.Rounded.FitScreen, null) },
                    onClick = {
                        resizeMode = when (resizeMode) {
                            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                        val persisted = when (resizeMode) {
                            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> 1
                            AspectRatioFrameLayout.RESIZE_MODE_FILL -> 2
                            else -> 0
                        }
                        PlayerPreferences.setVideoResizeMode(context, persisted)
                    }
                )
                VideoSettingItem(
                    title = "Velocidade",
                    subtitle = "${playbackSpeed}x • o Nerdora lembra sua escolha",
                    icon = { Icon(Icons.Rounded.Settings, null) },
                    onClick = {
                        val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
                        val currentIndex = speeds.indexOfFirst { kotlin.math.abs(it - playbackSpeed) < 0.01f }.coerceAtLeast(0)
                        playbackSpeed = speeds[(currentIndex + 1) % speeds.size]
                        player.setPlaybackSpeed(playbackSpeed)
                        PlayerPreferences.setVideoSpeed(context, playbackSpeed)
                    }
                )
                VideoSettingItem(
                    title = "Legenda externa",
                    subtitle = if (externalSubtitle != null || autoSubtitle != null) "Legenda carregada" else "Selecionar .SRT ou .VTT",
                    icon = { Icon(Icons.Rounded.Subtitles, null, tint = if (externalSubtitle != null || autoSubtitle != null) MaterialTheme.colorScheme.primary else Color.White) },
                    onClick = {
                        settingsOpen = false
                        subtitlePicker.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain"))
                    }
                )
                VideoSettingItem(
                    title = "Girar / paisagem",
                    subtitle = "Alternar orientação da tela",
                    icon = { Icon(Icons.Rounded.ScreenRotation, null) },
                    onClick = {
                        activity?.requestedOrientation = if (activity?.resources?.configuration?.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
                            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                )
                VideoSettingItem(
                    title = "Transmitir tela",
                    subtitle = "Abrir opções de transmissão do Android",
                    icon = { Icon(Icons.Rounded.Cast, null) },
                    onClick = {
                        settingsOpen = false
                        onCast()
                    }
                )
                VideoSettingItem(
                    title = "Picture-in-Picture",
                    subtitle = "Continuar assistindo sobre outros aplicativos",
                    icon = { Icon(Icons.Rounded.PictureInPictureAlt, null) },
                    onClick = {
                        settingsOpen = false
                        onEnterPictureInPicture()
                    }
                )
                VideoSettingItem(
                    title = "Bloquear controles",
                    subtitle = "Evita toques acidentais durante o vídeo",
                    icon = { Icon(Icons.Rounded.Lock, null) },
                    onClick = {
                        settingsOpen = false
                        locked = true
                        playerView?.hideController()
                        setControlsVisible(false)
                    }
                )

                TextButton(
                    onClick = {
                        settingsOpen = false
                        showControls()
                    },
                    modifier = Modifier.align(Alignment.End).padding(end = 12.dp, bottom = 12.dp)
                ) {
                    Text("Concluir")
                }
            }
        }
    }
}

@Composable
private fun VideoSettingItem(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        leadingContent = icon,
        colors = androidx.compose.material3.ListItemDefaults.colors(
            containerColor = Color.Transparent,
            headlineColor = Color.White,
            supportingColor = Color(0xFFCFC3DA),
            leadingIconColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    )
}

@Composable
private fun GestureZone(
    modifier: Modifier,
    onTap: () -> Unit,
    onDoubleTap: () -> Unit,
    onVerticalDrag: (Float) -> Unit
) {
    Box(
        modifier = modifier
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { onDoubleTap() }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount -> onVerticalDrag(dragAmount) }
            }
    )
}

package com.nerdora.player.ui

import android.content.ComponentName
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia
import com.nerdora.player.playback.PlaybackService
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NerdoraAudioPlayer(
    media: NerdoraMedia,
    queue: List<NerdoraMedia>,
    autoplay: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val token = remember { SessionToken(context, ComponentName(context, PlaybackService::class.java)) }
    val controllerFuture = remember { MediaController.Builder(context, token).buildAsync() }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(media.durationMs.coerceAtLeast(1L)) }
    var currentTitle by remember { mutableStateOf(media.title) }
    var currentArtist by remember { mutableStateOf(media.artist.ifBlank { media.description }) }
    var currentAlbum by remember { mutableStateOf(media.album) }
    var currentArtwork by remember { mutableStateOf(media.thumbnailUrl?.let(Uri::parse)) }
    var queueOpen by remember { mutableStateOf(false) }
    var sleepOpen by remember { mutableStateOf(false) }
    var lyricsOpen by remember { mutableStateOf(false) }
    var lyricsText by remember(media.id) { mutableStateOf("") }
    var remainingSleep by remember { mutableLongStateOf(PlayerPreferences.remainingSleepTimerMs(context)) }

    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            lyricsText = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            }.getOrDefault("Não foi possível ler a letra selecionada.")
            lyricsOpen = true
        }
    }

    DisposableEffect(controllerFuture) {
        val executor = ContextCompat.getMainExecutor(context)
        controllerFuture.addListener({
            runCatching { controllerFuture.get() }.onSuccess { controller = it }
        }, executor)
        onDispose {
            controller?.let { c ->
                val uri = c.currentMediaItem?.localConfiguration?.uri?.toString().orEmpty()
                if (uri.isNotBlank()) PlayerPreferences.savePosition(context, uri, c.currentPosition)
            }
            MediaController.releaseFuture(controllerFuture)
        }
    }

    LaunchedEffect(controller, media.id, queue.map { it.id }) {
        val c = controller ?: return@LaunchedEffect
        if (c.currentMediaItem?.mediaId != media.id) {
            val actualQueue = queue.filter { it.kind == MediaKind.AUDIO }.ifEmpty { listOf(media) }
            val index = actualQueue.indexOfFirst { it.id == media.id }.coerceAtLeast(0)
            val mediaItems = actualQueue.map { it.toMediaItem() }
            val start = if (PlayerPreferences.resumePlayback(context)) PlayerPreferences.loadPosition(context, media.url) else 0L
            c.setMediaItems(mediaItems, index, start)
            c.prepare()
            if (autoplay) c.play()
        }
    }

    LaunchedEffect(controller) {
        while (true) {
            controller?.let { c ->
                isPlaying = c.isPlaying
                position = c.currentPosition.coerceAtLeast(0L)
                if (c.duration > 0L) duration = c.duration
                currentTitle = c.currentMediaItem?.mediaMetadata?.title?.toString().orEmpty().ifBlank { media.title }
                currentArtist = c.currentMediaItem?.mediaMetadata?.artist?.toString().orEmpty().ifBlank { media.artist.ifBlank { media.description } }
                currentAlbum = c.currentMediaItem?.mediaMetadata?.albumTitle?.toString().orEmpty()
                currentArtwork = c.currentMediaItem?.mediaMetadata?.artworkUri ?: media.thumbnailUrl?.let(Uri::parse)
                val uri = c.currentMediaItem?.localConfiguration?.uri?.toString().orEmpty()
                if (position > 5_000L && uri.isNotBlank()) PlayerPreferences.savePosition(context, uri, position)
            }
            remainingSleep = PlayerPreferences.remainingSleepTimerMs(context)
            delay(500)
        }
    }

    fun openSystemEqualizer() {
        val intent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
            putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
        }
        runCatching { context.startActivity(intent) }.onFailure {
            runCatching { context.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }
        }
    }

    val c = controller
    Box(
        modifier = modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF231038), Color.Black))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(232.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF2E1065)),
                contentAlignment = Alignment.Center
            ) {
                if (currentArtwork != null) {
                    AsyncImage(currentArtwork, currentTitle, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Icon(Icons.Rounded.LibraryMusic, null, tint = Color.White, modifier = Modifier.size(92.dp))
                }
            }
            Spacer(Modifier.size(22.dp))
            Text(currentTitle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(currentArtist, color = Color(0xFFD8CDE5), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (currentAlbum.isNotBlank()) Text(currentAlbum, color = Color(0xFF9E8EAA), fontSize = 11.sp)
            Spacer(Modifier.size(20.dp))
            Slider(
                value = position.coerceAtMost(duration.coerceAtLeast(1L)).toFloat(),
                onValueChange = { value -> position = value.toLong(); c?.seekTo(position) },
                valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatDuration(position), color = Color(0xFFCFC3DA), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(formatDuration(duration), color = Color(0xFFCFC3DA), fontSize = 11.sp)
            }
            Spacer(Modifier.size(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                IconButton(onClick = { c?.shuffleModeEnabled = !(c?.shuffleModeEnabled ?: false) }) {
                    Icon(Icons.Rounded.Shuffle, "Aleatório", tint = if (c?.shuffleModeEnabled == true) MaterialTheme.colorScheme.primary else Color.White)
                }
                IconButton(onClick = { c?.seekToPreviousMediaItem() }) { Icon(Icons.Rounded.SkipPrevious, "Anterior", tint = Color.White) }
                Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                    IconButton(onClick = { if (c?.isPlaying == true) c.pause() else c?.play() }, modifier = Modifier.fillMaxSize()) {
                        Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (isPlaying) "Pausar" else "Reproduzir", tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                }
                IconButton(onClick = { c?.seekToNextMediaItem() }) { Icon(Icons.Rounded.SkipNext, "Próxima", tint = Color.White) }
                IconButton(onClick = {
                    c?.repeatMode = when (c?.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }) {
                    Icon(Icons.Rounded.Repeat, "Repetir", tint = if (c?.repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else Color.White)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { queueOpen = true }) { Icon(Icons.Rounded.PlaylistPlay, null); Text(" Fila") }
                TextButton(onClick = { sleepOpen = true }) { Text(if (remainingSleep > 0) "Timer ${formatDuration(remainingSleep)}" else "Timer") }
                TextButton(onClick = ::openSystemEqualizer) { Text("Som") }
                TextButton(onClick = { lyricsPicker.launch(arrayOf("text/plain", "application/octet-stream")) }) { Text("Letra") }
            }
        }
    }

    if (queueOpen) {
        ModalBottomSheet(onDismissRequest = { queueOpen = false }) {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
                Text("Fila de reprodução", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(16.dp))
                val controllerNow = c
                if (controllerNow != null) {
                    repeat(controllerNow.mediaItemCount) { index ->
                        val item = controllerNow.getMediaItemAt(index)
                        val selected = index == controllerNow.currentMediaItemIndex
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                controllerNow.seekToDefaultPosition(index)
                                controllerNow.play()
                                queueOpen = false
                            }.padding(horizontal = 16.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.LibraryMusic, null, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                            Column(Modifier.padding(start = 10.dp).weight(1f)) {
                                Text(item.mediaMetadata.title?.toString().orEmpty().ifBlank { "Faixa ${index + 1}" }, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                                Text(item.mediaMetadata.artist?.toString().orEmpty(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    if (sleepOpen) {
        ModalBottomSheet(onDismissRequest = { sleepOpen = false }) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Temporizador", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("O Nerdora pausará a música quando o tempo terminar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 45, 60).forEach { minutes ->
                        Button(onClick = {
                            PlayerPreferences.setSleepTimerMinutes(context, minutes)
                            remainingSleep = PlayerPreferences.remainingSleepTimerMs(context)
                            sleepOpen = false
                        }) { Text("${minutes}m") }
                    }
                }
                if (remainingSleep > 0L) {
                    TextButton(onClick = {
                        PlayerPreferences.clearSleepTimer(context)
                        remainingSleep = 0L
                        sleepOpen = false
                    }) { Text("Cancelar temporizador") }
                }
            }
        }
    }

    if (lyricsOpen) {
        ModalBottomSheet(onDismissRequest = { lyricsOpen = false }) {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()).padding(20.dp)) {
                Text("Letra", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.size(10.dp))
                Text(cleanLrc(lyricsText).ifBlank { "Arquivo de letra vazio." }, lineHeight = 24.sp)
            }
        }
    }
}

private fun cleanLrc(text: String): String = text
    .lineSequence()
    .map { line -> line.replace(Regex("\\[[0-9]{1,2}:[0-9]{2}(?:\\.[0-9]{1,3})?]"), "").trim() }
    .filter { it.isNotBlank() && !it.startsWith("[") }
    .joinToString("\n")

private fun NerdoraMedia.toMediaItem(): MediaItem {
    val metadata = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist.ifBlank { description })
        .setAlbumTitle(album)
        .apply { thumbnailUrl?.let { setArtworkUri(Uri.parse(it)) } }
        .build()
    return MediaItem.Builder()
        .setMediaId(id)
        .setUri(url)
        .setMediaMetadata(metadata)
        .build()
}

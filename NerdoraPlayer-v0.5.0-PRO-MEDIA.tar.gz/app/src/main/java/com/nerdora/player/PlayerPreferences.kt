package com.nerdora.player

import android.content.Context
import org.json.JSONObject

object PlayerPreferences {
    private const val PREFS = "nerdora_player_prefs"
    private const val AUTOPLAY = "autoplay"
    private const val RESUME = "resume"
    private const val BACKGROUND_AUDIO = "background_audio"
    private const val THEME = "theme"
    private const val ACCENT = "accent"
    private const val SEEK_SECONDS = "seek_seconds"
    private const val SLIDESHOW_SECONDS = "slideshow_seconds"
    private const val VIDEO_SPEED = "video_speed"
    private const val VIDEO_RESIZE = "video_resize"
    private const val GRID_SIZE = "grid_size"
    private const val REDUCE_ANIMATIONS = "reduce_animations"
    private const val ONBOARDING_DONE = "onboarding_done"
    private const val LAST_MEDIA_SCAN = "last_media_scan"
    private const val SLEEP_TIMER_DEADLINE = "sleep_timer_deadline"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun autoplay(context: Context): Boolean = prefs(context).getBoolean(AUTOPLAY, true)
    fun setAutoplay(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(AUTOPLAY, enabled).apply()

    fun resumePlayback(context: Context): Boolean = prefs(context).getBoolean(RESUME, true)
    fun setResumePlayback(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(RESUME, enabled).apply()

    fun backgroundAudio(context: Context): Boolean = prefs(context).getBoolean(BACKGROUND_AUDIO, true)
    fun setBackgroundAudio(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(BACKGROUND_AUDIO, enabled).apply()

    fun theme(context: Context): String = prefs(context).getString(THEME, "NERDORA") ?: "NERDORA"
    fun setTheme(context: Context, value: String) = prefs(context).edit().putString(THEME, value).apply()

    fun accent(context: Context): String = prefs(context).getString(ACCENT, "PURPLE") ?: "PURPLE"
    fun setAccent(context: Context, value: String) = prefs(context).edit().putString(ACCENT, value).apply()

    fun seekSeconds(context: Context): Int = prefs(context).getInt(SEEK_SECONDS, 10).coerceIn(5, 30)
    fun setSeekSeconds(context: Context, seconds: Int) = prefs(context).edit().putInt(SEEK_SECONDS, seconds.coerceIn(5, 30)).apply()

    fun slideshowSeconds(context: Context): Int = prefs(context).getInt(SLIDESHOW_SECONDS, 4).coerceIn(2, 10)
    fun setSlideshowSeconds(context: Context, seconds: Int) = prefs(context).edit().putInt(SLIDESHOW_SECONDS, seconds.coerceIn(2, 10)).apply()

    fun videoSpeed(context: Context): Float = prefs(context).getFloat(VIDEO_SPEED, 1f).coerceIn(0.5f, 2f)
    fun setVideoSpeed(context: Context, speed: Float) = prefs(context).edit().putFloat(VIDEO_SPEED, speed.coerceIn(0.5f, 2f)).apply()

    fun videoResizeMode(context: Context): Int = prefs(context).getInt(VIDEO_RESIZE, 0)
    fun setVideoResizeMode(context: Context, mode: Int) = prefs(context).edit().putInt(VIDEO_RESIZE, mode).apply()

    /** 0 = compacta, 1 = normal, 2 = grande */
    fun gridSize(context: Context): Int = prefs(context).getInt(GRID_SIZE, 1).coerceIn(0, 2)
    fun setGridSize(context: Context, value: Int) = prefs(context).edit().putInt(GRID_SIZE, value.coerceIn(0, 2)).apply()

    fun reduceAnimations(context: Context): Boolean = prefs(context).getBoolean(REDUCE_ANIMATIONS, false)
    fun setReduceAnimations(context: Context, value: Boolean) = prefs(context).edit().putBoolean(REDUCE_ANIMATIONS, value).apply()

    fun onboardingDone(context: Context): Boolean = prefs(context).getBoolean(ONBOARDING_DONE, false)
    fun setOnboardingDone(context: Context, value: Boolean = true) = prefs(context).edit().putBoolean(ONBOARDING_DONE, value).apply()

    fun lastMediaScan(context: Context): Long = prefs(context).getLong(LAST_MEDIA_SCAN, 0L)
    fun setLastMediaScan(context: Context, value: Long = System.currentTimeMillis()) = prefs(context).edit().putLong(LAST_MEDIA_SCAN, value).apply()

    fun sleepTimerDeadline(context: Context): Long = prefs(context).getLong(SLEEP_TIMER_DEADLINE, 0L)
    fun setSleepTimerMinutes(context: Context, minutes: Int) {
        val deadline = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60_000L
        prefs(context).edit().putLong(SLEEP_TIMER_DEADLINE, deadline).apply()
    }
    fun clearSleepTimer(context: Context) = prefs(context).edit().putLong(SLEEP_TIMER_DEADLINE, 0L).apply()
    fun remainingSleepTimerMs(context: Context): Long = (sleepTimerDeadline(context) - System.currentTimeMillis()).coerceAtLeast(0L)

    fun loadPosition(context: Context, mediaKey: String): Long =
        prefs(context).getLong("position_${mediaKey.hashCode()}", 0L)

    fun savePosition(context: Context, mediaKey: String, positionMs: Long) {
        val key = "position_${mediaKey.hashCode()}"
        if (positionMs < 5_000L) prefs(context).edit().remove(key).apply()
        else prefs(context).edit().putLong(key, positionMs).apply()
    }

    fun clearPosition(context: Context, mediaKey: String) =
        prefs(context).edit().remove("position_${mediaKey.hashCode()}").apply()

    fun exportJson(context: Context): JSONObject {
        val all = prefs(context).all
        val obj = JSONObject()
        all.forEach { (key, value) ->
            when (value) {
                is Boolean, is Int, is Long, is Float, is String -> obj.put(key, value)
            }
        }
        return obj
    }

    fun importJson(context: Context, obj: JSONObject) {
        val edit = prefs(context).edit()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            when (val value = obj.opt(key)) {
                is Boolean -> edit.putBoolean(key, value)
                is Int -> edit.putInt(key, value)
                is Long -> edit.putLong(key, value)
                is Double -> edit.putFloat(key, value.toFloat())
                is String -> edit.putString(key, value)
            }
        }
        edit.apply()
    }
}

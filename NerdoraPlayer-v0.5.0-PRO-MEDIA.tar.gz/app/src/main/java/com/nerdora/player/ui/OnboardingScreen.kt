package com.nerdora.player.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nerdora.player.R

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val titles = listOf("Bem-vindo ao Nerdora Player", "Sua mídia, do seu jeito", "Privacidade e controle")
    val descriptions = listOf(
        "Fotos, vídeos e músicas em uma central de mídia feita para o ecossistema Nerdora.",
        "Continue de onde parou, use playlists, mini player, PiP, legendas e controles avançados.",
        "Seus arquivos permanecem no aparelho. Você escolhe o que o Nerdora pode acessar e pode ocultar itens dentro do app."
    )
    val icons = listOf(Icons.Rounded.PlayArrow, Icons.Rounded.PermMedia, Icons.Rounded.Lock)

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF3B0C72), MaterialTheme.colorScheme.background))
            )
        ) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.nerdora_player_mark),
                    contentDescription = "Nerdora Player",
                    modifier = Modifier.size(116.dp).clip(RoundedCornerShape(28.dp)),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.height(28.dp))
                Box(Modifier.size(68.dp).clip(CircleShape).background(Color(0x332A123E)), contentAlignment = Alignment.Center) {
                    Icon(icons[page], null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.height(18.dp))
                Text(titles[page], color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text(descriptions[page], color = Color(0xFFE4D7F5), fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(28.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    repeat(3) { i ->
                        Box(
                            Modifier.size(if (i == page) 18.dp else 8.dp, 8.dp)
                                .clip(CircleShape)
                                .background(if (i == page) MaterialTheme.colorScheme.primary else Color(0x557C6B89))
                        )
                    }
                }
                Spacer(Modifier.height(30.dp))
                Button(
                    onClick = { if (page < 2) page++ else onFinish() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (page < 2) "Continuar" else "Começar") }
                if (page < 2) {
                    OutlinedButton(onClick = onFinish, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Text("Pular")
                    }
                }
            }
        }
    }
}

package com.nerdora.player.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nerdora.player.BuildConfig
import com.nerdora.player.NerdoraBackup
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.UpdateChecker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(
    hiddenCount: Int,
    trashCount: Int,
    onThemeChanged: () -> Unit,
    onOpenPrivate: () -> Unit,
    onOpenTrash: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onClearHistory: () -> Unit,
    onOpenCastSettings: () -> Unit,
    onLibraryChanged: () -> Unit
) {
    val context = LocalContext.current
    var autoplay by remember { mutableStateOf(PlayerPreferences.autoplay(context)) }
    var resume by remember { mutableStateOf(PlayerPreferences.resumePlayback(context)) }
    var backgroundAudio by remember { mutableStateOf(PlayerPreferences.backgroundAudio(context)) }
    var theme by remember { mutableStateOf(PlayerPreferences.theme(context)) }
    var accent by remember { mutableStateOf(PlayerPreferences.accent(context)) }
    var seekSeconds by remember { mutableStateOf(PlayerPreferences.seekSeconds(context)) }
    var slideshowSeconds by remember { mutableStateOf(PlayerPreferences.slideshowSeconds(context)) }
    var reduceAnimations by remember { mutableStateOf(PlayerPreferences.reduceAnimations(context)) }
    var updateText by remember { mutableStateOf("") }
    var updateUrl by remember { mutableStateOf("") }
    var checking by remember { mutableStateOf(false) }
    var showChangelog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { NerdoraBackup.write(context, uri) } }
            Toast.makeText(context, if (result.isSuccess) "Backup salvo" else "Falha ao salvar backup", Toast.LENGTH_LONG).show()
        }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { NerdoraBackup.restore(context, uri) } }
            if (result.isSuccess) {
                theme = PlayerPreferences.theme(context)
                accent = PlayerPreferences.accent(context)
                autoplay = PlayerPreferences.autoplay(context)
                resume = PlayerPreferences.resumePlayback(context)
                backgroundAudio = PlayerPreferences.backgroundAudio(context)
                seekSeconds = PlayerPreferences.seekSeconds(context)
                slideshowSeconds = PlayerPreferences.slideshowSeconds(context)
                reduceAnimations = PlayerPreferences.reduceAnimations(context)
                onLibraryChanged()
            }
            Toast.makeText(context, if (result.isSuccess) "Backup restaurado" else "Backup inválido", Toast.LENGTH_LONG).show()
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Configurações", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Ajustes finais do Nerdora Player Pro Media", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)

            SettingHeader("Reprodução")
            ToggleSetting("Autoplay", "Inicia automaticamente ao abrir uma mídia", autoplay) {
                autoplay = it; PlayerPreferences.setAutoplay(context, it)
            }
            ToggleSetting("Continuar de onde parou", "Guarda a posição de vídeos e músicas", resume) {
                resume = it; PlayerPreferences.setResumePlayback(context, it)
            }
            ToggleSetting("Áudio em segundo plano", "Continua tocando com o app minimizado", backgroundAudio) {
                backgroundAudio = it; PlayerPreferences.setBackgroundAudio(context, it)
            }

            Text("Avanço/retrocesso", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(5, 10, 15, 30).forEach { value ->
                    FilterChip(selected = seekSeconds == value, onClick = {
                        seekSeconds = value; PlayerPreferences.setSeekSeconds(context, value)
                    }, label = { Text("${value}s") })
                }
            }

            Text("Apresentação de fotos", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(2, 4, 6, 10).forEach { value ->
                    FilterChip(selected = slideshowSeconds == value, onClick = {
                        slideshowSeconds = value; PlayerPreferences.setSlideshowSeconds(context, value)
                    }, label = { Text("${value}s") })
                }
            }

            SettingHeader("Aparência e acessibilidade")
            Text("Tema", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = theme == "NERDORA", onClick = {
                    theme = "NERDORA"; PlayerPreferences.setTheme(context, theme); onThemeChanged()
                }, label = { Text("Nerdora") })
                FilterChip(selected = theme == "AMOLED", onClick = {
                    theme = "AMOLED"; PlayerPreferences.setTheme(context, theme); onThemeChanged()
                }, label = { Text("Preto AMOLED") })
            }
            Text("Cor de destaque", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("PURPLE" to "Roxo", "ROSE" to "Rosa", "CYAN" to "Ciano").forEach { (id, label) ->
                    FilterChip(selected = accent == id, onClick = {
                        accent = id; PlayerPreferences.setAccent(context, id); onThemeChanged()
                    }, label = { Text(label) })
                }
            }
            ToggleSetting("Reduzir animações", "Prefere transições discretas e menos movimento", reduceAnimations) {
                reduceAnimations = it; PlayerPreferences.setReduceAnimations(context, it)
            }

            SettingHeader("Privacidade e biblioteca")
            ActionSetting(Icons.Rounded.Lock, "Mídia oculta", "$hiddenCount item(ns). Protegido pela biometria/tela de bloqueio.", onOpenPrivate)
            ActionSetting(Icons.Rounded.DeleteSweep, "Lixeira do Nerdora", "$trashCount item(ns). Não apaga os arquivos físicos do celular.", onOpenTrash)
            ActionSetting(Icons.Rounded.DeleteSweep, "Limpar histórico", "Apaga a lista de reproduzidos recentemente", onClearHistory)
            Text("A área oculta e a lixeira são camadas do Nerdora: os arquivos originais continuam no armazenamento do Android.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)

            SettingHeader("Backup")
            ActionSetting(Icons.Rounded.Share, "Exportar backup", "Favoritos, playlists, histórico e preferências em um arquivo JSON") {
                exportBackup.launch("NerdoraPlayer-backup.json")
            }
            ActionSetting(Icons.Rounded.Refresh, "Restaurar backup", "Importar um backup criado pelo Nerdora Player") {
                importBackup.launch(arrayOf("application/json", "text/plain"))
            }

            SettingHeader("TV e dispositivos")
            ActionSetting(Icons.Rounded.Cast, "Transmitir / Espelhar tela", "Abre as opções de transmissão do Android.", onOpenCastSettings)
            Text("O app mantém launcher para Android TV e layouts adaptativos básicos. Reprodução SMB/DLNA dedicada fica reservada para uma integração futura.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)

            SettingHeader("Diagnóstico")
            ActionSetting(Icons.Rounded.Info, "Diagnóstico do aparelho", "Android, arquitetura e codecs de áudio/vídeo disponíveis", onOpenDiagnostics)

            SettingHeader("Atualizações")
            ActionSetting(Icons.Rounded.SystemUpdate, "Verificar atualizações", if (BuildConfig.GITHUB_REPOSITORY.isBlank()) "Repositório não informado no build." else BuildConfig.GITHUB_REPOSITORY) {
                if (!checking) {
                    checking = true
                    scope.launch {
                        val result = UpdateChecker.check(BuildConfig.GITHUB_REPOSITORY, BuildConfig.VERSION_NAME)
                        updateText = result.message
                        updateUrl = result.releaseUrl
                        checking = false
                    }
                }
            }
            if (updateText.isNotBlank()) {
                Text(updateText, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                if (updateUrl.isNotBlank()) {
                    Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl))) }) { Text("Abrir release") }
                }
            }

            SettingHeader("Sobre")
            ActionSetting(Icons.Rounded.Info, "Nerdora Player ${BuildConfig.VERSION_NAME}", "Ver novidades da versão") { showChangelog = true }
            Text("Fotos, vídeos e músicas em um só lugar. Esta versão foi preparada como base final antes da integração ao Nerdora.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Spacer(Modifier.size(100.dp))
        }
    }

    if (showChangelog) {
        AlertDialog(
            onDismissRequest = { showChangelog = false },
            title = { Text("Nerdora Player 0.5.0 — Pro Media") },
            text = {
                Text(
                    "• Biblioteca com cache local e abertura mais rápida\n" +
                        "• Mini player com swipe e botão fechar\n" +
                        "• Fila de música, timer, letras .LRC e atalho de som\n" +
                        "• Velocidade e ajuste de tela do vídeo persistentes\n" +
                        "• Grade configurável\n" +
                        "• Lixeira lógica, backup/restauração e diagnóstico\n" +
                        "• Abrir mídia por URL HTTP/HTTPS\n" +
                        "• Onboarding, atualização e acabamento de produto"
                )
            },
            confirmButton = { TextButton(onClick = { showChangelog = false }) { Text("Fechar") } }
        )
    }
}

@Composable
private fun SettingHeader(text: String) {
    HorizontalDivider(modifier = Modifier.padding(top = 8.dp))
    Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun ToggleSetting(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionSetting(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
    }
}

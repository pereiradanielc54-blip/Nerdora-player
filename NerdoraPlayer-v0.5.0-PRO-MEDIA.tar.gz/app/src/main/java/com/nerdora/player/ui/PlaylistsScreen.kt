package com.nerdora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nerdora.player.model.NerdoraMedia

@Composable
fun PlaylistsScreen(
    playlists: Map<String, List<String>>,
    allItems: List<NerdoraMedia>,
    onCreate: (String) -> Unit,
    onDelete: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onDuplicate: (String) -> Unit,
    onOpen: (List<NerdoraMedia>) -> Unit
) {
    var createDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renameFrom by remember { mutableStateOf<String?>(null) }
    var renameTo by remember { mutableStateOf("") }
    val byId = allItems.associateBy { it.id }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                    Text("Playlists", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Crie filas com suas músicas e vídeos", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
                if (playlists.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.PlaylistPlay, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(54.dp))
                            Text("Nenhuma playlist ainda", fontWeight = FontWeight.Bold)
                            Text("Toque em + para criar a primeira.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(playlists.toList(), key = { it.first }) { (name, ids) ->
                            val resolved = ids.mapNotNull(byId::get)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(15.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onOpen(resolved) }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Rounded.PlaylistPlay, null, tint = MaterialTheme.colorScheme.primary) }
                                Spacer(Modifier.size(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, fontWeight = FontWeight.Bold)
                                    Text("${resolved.size} itens", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Box {
                                    IconButton(onClick = { menuFor = name }) { Icon(Icons.Rounded.MoreVert, "Mais opções") }
                                    DropdownMenu(expanded = menuFor == name, onDismissRequest = { menuFor = null }) {
                                        DropdownMenuItem(text = { Text("Renomear") }, onClick = {
                                            renameFrom = name
                                            renameTo = name
                                            menuFor = null
                                        })
                                        DropdownMenuItem(text = { Text("Duplicar") }, onClick = {
                                            onDuplicate(name)
                                            menuFor = null
                                        })
                                        DropdownMenuItem(text = { Text("Excluir") }, onClick = {
                                            onDelete(name)
                                            menuFor = null
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            }
            FloatingActionButton(onClick = { createDialog = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
                Icon(Icons.Rounded.Add, "Criar playlist")
            }
        }
    }

    if (createDialog) {
        AlertDialog(
            onDismissRequest = { createDialog = false },
            title = { Text("Nova playlist") },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true, label = { Text("Nome") })
            },
            confirmButton = {
                Button(onClick = {
                    if (newName.isNotBlank()) onCreate(newName)
                    newName = ""
                    createDialog = false
                }) { Text("Criar") }
            },
            dismissButton = { TextButton(onClick = { createDialog = false }) { Text("Cancelar") } }
        )
    }

    if (renameFrom != null) {
        AlertDialog(
            onDismissRequest = { renameFrom = null },
            title = { Text("Renomear playlist") },
            text = { OutlinedTextField(value = renameTo, onValueChange = { renameTo = it }, singleLine = true, label = { Text("Nome") }) },
            confirmButton = {
                Button(onClick = {
                    val from = renameFrom
                    if (from != null && renameTo.isNotBlank()) onRename(from, renameTo)
                    renameFrom = null
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { renameFrom = null }) { Text("Cancelar") } }
        )
    }
}

package com.nerdora.player.ui

import android.content.ComponentName
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.nerdora.player.playback.PlaybackService
import kotlinx.coroutines.delay

@Composable
fun NerdoraMiniAudioPlayer(
    onExpand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val token = remember { SessionToken(context, ComponentName(context, PlaybackService::class.java)) }
    val controllerFuture = remember { MediaController.Builder(context, token).buildAsync() }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var mediaId by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var artwork by remember { mutableStateOf<Uri?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragTotal by remember { mutableFloatStateOf(0f) }

    DisposableEffect(controllerFuture) {
        val executor = ContextCompat.getMainExecutor(context)
        controllerFuture.addListener({
            runCatching { controllerFuture.get() }.onSuccess { controller = it }
        }, executor)
        onDispose { MediaController.releaseFuture(controllerFuture) }
    }

    LaunchedEffect(controller) {
        while (true) {
            controller?.let { c ->
                val item = c.currentMediaItem
                mediaId = item?.mediaId.orEmpty()
                title = item?.mediaMetadata?.title?.toString().orEmpty()
                artist = item?.mediaMetadata?.artist?.toString().orEmpty()
                artwork = item?.mediaMetadata?.artworkUri
                isPlaying = c.isPlaying
                position = c.currentPosition.coerceAtLeast(0L)
                duration = c.duration.coerceAtLeast(0L)
            }
            delay(300L)
        }
    }

    if (mediaId.isBlank()) return

    val progress = if (duration > 0L) (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .pointerInput(mediaId) {
                detectHorizontalDragGestures(
                    onDragStart = { dragTotal = 0f },
                    onHorizontalDrag = { _, amount -> dragTotal += amount },
                    onDragEnd = {
                        if (dragTotal <= -80f && controller?.hasNextMediaItem() == true) controller?.seekToNextMediaItem()
                        if (dragTotal >= 80f && controller?.hasPreviousMediaItem() == true) controller?.seekToPreviousMediaItem()
                        dragTotal = 0f
                    }
                )
            },
        color = Color(0xFF17111F),
        tonalElevation = 6.dp,
        shadowElevation = 8.dp
    ) {
        Column(Modifier.fillMaxWidth()) {
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color(0xFF34293F)
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(11.dp)).clickable { onExpand(mediaId) },
                    contentAlignment = Alignment.Center
                ) {
                    if (artwork != null) {
                        AsyncImage(model = artwork, contentDescription = title, modifier = Modifier.size(46.dp), contentScale = ContentScale.Crop)
                    } else {
                        Surface(color = Color(0xFF2E1065), modifier = Modifier.size(46.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.LibraryMusic, null, tint = Color.White) }
                        }
                    }
                }

                Column(Modifier.padding(start = 10.dp).weight(1f).clickable { onExpand(mediaId) }) {
                    Text(
                        text = title.ifBlank { "Reproduzindo no Nerdora" },
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (artist.isNotBlank()) {
                        Text(text = artist, color = Color(0xFFCFC3DA), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                Spacer(Modifier.size(2.dp))
                IconButton(onClick = { controller?.let { c -> if (c.isPlaying) c.pause() else c.play() } }) {
                    Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (isPlaying) "Pausar" else "Reproduzir", tint = Color.White)
                }
                IconButton(onClick = { controller?.seekToNextMediaItem() }, enabled = controller?.hasNextMediaItem() == true) {
                    Icon(Icons.Rounded.SkipNext, "Próxima", tint = if (controller?.hasNextMediaItem() == true) Color.White else Color(0xFF6F6675))
                }
                IconButton(onClick = {
                    controller?.stop()
                    controller?.clearMediaItems()
                    mediaId = ""
                }) { Icon(Icons.Rounded.Close, "Fechar player", tint = Color.White) }
            }
        }
    }
}

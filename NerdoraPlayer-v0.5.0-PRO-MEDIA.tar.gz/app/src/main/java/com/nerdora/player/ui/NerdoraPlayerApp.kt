package com.nerdora.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.nerdora.player.LibraryStore
import com.nerdora.player.MainActivity
import com.nerdora.player.MediaPermissions
import com.nerdora.player.PlayerPreferences
import com.nerdora.player.data.LocalMediaRepository
import com.nerdora.player.data.MediaIndexCache
import com.nerdora.player.data.SampleMedia
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class AppScreen { HOME, LIBRARY, FOLDERS, PLAYLISTS, SETTINGS, HIDDEN, TRASH, DIAGNOSTICS }

@Composable
fun NerdoraPlayerApp(
    activity: MainActivity,
    externalMedia: NerdoraMedia?,
    onEnterPictureInPicture: () -> Unit,
    onThemeChanged: () -> Unit
) {
    var screenName by rememberSaveable { mutableStateOf(AppScreen.HOME.name) }
    var localMedia by remember { mutableStateOf<List<NerdoraMedia>>(emptyList()) }
    var permissionEpoch by remember { mutableIntStateOf(0) }
    var storeEpoch by remember { mutableIntStateOf(0) }
    var hasMediaAccess by remember { mutableStateOf(MediaPermissions.hasAnyAccess(activity)) }
    var viewerItems by remember { mutableStateOf<List<NerdoraMedia>>(emptyList()) }
    var viewerIndex by rememberSaveable { mutableStateOf<Int?>(if (externalMedia != null) 0 else null) }
    var libraryOverride by remember { mutableStateOf<List<NerdoraMedia>?>(null) }
    var libraryFavoritesOnly by remember { mutableStateOf(false) }
    var showOpenUrl by remember { mutableStateOf(false) }
    var onboarding by remember { mutableStateOf(!PlayerPreferences.onboardingDone(activity) && externalMedia == null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasMediaAccess = MediaPermissions.hasAnyAccess(activity)
        permissionEpoch++
    }

    LaunchedEffect(permissionEpoch, hasMediaAccess) {
        if (!hasMediaAccess) {
            localMedia = emptyList()
            return@LaunchedEffect
        }
        val cached = withContext(Dispatchers.IO) { MediaIndexCache.read(activity) }.filter { item ->
            when (item.kind) {
                MediaKind.IMAGE -> MediaPermissions.hasPhotoAccess(activity)
                MediaKind.VIDEO -> MediaPermissions.hasVideoAccess(activity)
                MediaKind.AUDIO -> MediaPermissions.hasAudioAccess(activity)
            }
        }
        if (cached.isNotEmpty()) localMedia = cached
        val stale = System.currentTimeMillis() - PlayerPreferences.lastMediaScan(activity) > 5 * 60_000L
        if (cached.isEmpty() || stale || permissionEpoch > 0) {
            val fresh = withContext(Dispatchers.IO) { LocalMediaRepository.loadAll(activity) }
            localMedia = fresh
            withContext(Dispatchers.IO) { MediaIndexCache.replace(activity, fresh) }
            PlayerPreferences.setLastMediaScan(activity)
        }
    }

    LaunchedEffect(externalMedia?.id) {
        if (externalMedia != null) {
            viewerItems = listOf(externalMedia)
            viewerIndex = 0
        }
    }

    if (onboarding) {
        OnboardingScreen(onFinish = {
            PlayerPreferences.setOnboardingDone(activity)
            onboarding = false
        })
        return
    }

    val hiddenIds = remember(localMedia, storeEpoch) { LibraryStore.hiddenIds(activity) }
    val trashIds = remember(localMedia, storeEpoch) { LibraryStore.trashIds(activity) }
    val favoriteIds = remember(localMedia, storeEpoch) { LibraryStore.favoriteIds(activity) }
    val recentIds = remember(localMedia, storeEpoch) { LibraryStore.recentIds(activity) }
    val playlists = remember(localMedia, storeEpoch) { LibraryStore.playlists(activity) }
    val visibleMedia = remember(localMedia, hiddenIds, trashIds) { localMedia.filterNot { hiddenIds.contains(it.id) || trashIds.contains(it.id) } }
    val hiddenMedia = remember(localMedia, hiddenIds, trashIds) { localMedia.filter { hiddenIds.contains(it.id) && !trashIds.contains(it.id) } }
    val trashMedia = remember(localMedia, trashIds) { localMedia.filter { trashIds.contains(it.id) } }

    val selected = viewerIndex
    if (selected != null) {
        val items = viewerItems.ifEmpty { externalMedia?.let { listOf(it) } ?: SampleMedia.items }
        MediaViewerScreen(
            activity = activity,
            items = items,
            initialIndex = selected.coerceIn(items.indices),
            autoplay = PlayerPreferences.autoplay(activity),
            onClose = { viewerIndex = null },
            onEnterPictureInPicture = onEnterPictureInPicture,
            onStoreChanged = { storeEpoch++ }
        )
        return
    }

    val screen = runCatching { AppScreen.valueOf(screenName) }.getOrDefault(AppScreen.HOME)

    fun openItems(items: List<NerdoraMedia>, index: Int) {
        if (items.isEmpty()) return
        viewerItems = items
        viewerIndex = index.coerceIn(items.indices)
    }

    fun openPrivate() {
        activity.authenticatePrivateMedia { success ->
            if (success) screenName = AppScreen.HIDDEN.name
        }
    }

    val miniPlayerItems = remember(visibleMedia, viewerItems, externalMedia) {
        (viewerItems + visibleMedia + SampleMedia.items + listOfNotNull(externalMedia))
            .filter { it.kind == MediaKind.AUDIO }
            .distinctBy { it.id }
    }

    val showBottomBar = screen !in setOf(AppScreen.HIDDEN, AppScreen.TRASH, AppScreen.DIAGNOSTICS)

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                Column {
                    NerdoraMiniAudioPlayer(
                        onExpand = { playingId ->
                            val index = miniPlayerItems.indexOfFirst { it.id == playingId }
                            if (index >= 0) openItems(miniPlayerItems, index)
                        }
                    )
                    NavigationBar {
                        listOf(
                            Triple(AppScreen.HOME, "Início", Icons.Rounded.Home),
                            Triple(AppScreen.LIBRARY, "Biblioteca", Icons.Rounded.PermMedia),
                            Triple(AppScreen.FOLDERS, "Pastas", Icons.Rounded.Folder),
                            Triple(AppScreen.PLAYLISTS, "Playlists", Icons.Rounded.LibraryMusic),
                            Triple(AppScreen.SETTINGS, "Ajustes", Icons.Rounded.Settings)
                        ).forEach { (target, label, icon) ->
                            NavigationBarItem(
                                selected = screen == target,
                                onClick = {
                                    screenName = target.name
                                    if (target == AppScreen.LIBRARY) {
                                        libraryOverride = null
                                        libraryFavoritesOnly = false
                                    }
                                },
                                icon = { Icon(icon, label) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        androidx.compose.foundation.layout.Box(Modifier.padding(padding)) {
            when (screen) {
                AppScreen.HOME -> HomeScreen(
                    items = visibleMedia,
                    demoItems = SampleMedia.items,
                    hasMediaAccess = hasMediaAccess,
                    favoriteIds = favoriteIds,
                    recentIds = recentIds,
                    hiddenCount = hiddenMedia.size,
                    positionFor = { PlayerPreferences.loadPosition(activity, it.url) },
                    onRequestPermissions = { permissionLauncher.launch(MediaPermissions.permissionsToRequest()) },
                    onOpenItems = ::openItems,
                    onOpenLibrary = {
                        libraryOverride = null
                        libraryFavoritesOnly = false
                        screenName = AppScreen.LIBRARY.name
                    },
                    onOpenFolders = { screenName = AppScreen.FOLDERS.name },
                    onOpenFavorites = {
                        libraryOverride = null
                        libraryFavoritesOnly = true
                        screenName = AppScreen.LIBRARY.name
                    },
                    onOpenPrivate = ::openPrivate,
                    onOpenLink = { showOpenUrl = true }
                )
                AppScreen.LIBRARY -> LibraryScreen(
                    items = libraryOverride ?: visibleMedia,
                    favoriteIds = favoriteIds,
                    initialFavoritesOnly = libraryFavoritesOnly,
                    onOpenItems = ::openItems,
                    onRefresh = { permissionEpoch++ },
                    onFavorite = { id, value -> LibraryStore.setFavorite(activity, id, value); storeEpoch++ },
                    onHide = { id, value -> LibraryStore.setHidden(activity, id, value); storeEpoch++ },
                    onTrash = { id -> LibraryStore.moveToTrash(activity, id); storeEpoch++ },
                    onShare = { shareMedia(activity, it) }
                )
                AppScreen.FOLDERS -> FoldersScreen(
                    items = visibleMedia,
                    onOpenFolder = { group ->
                        libraryOverride = group
                        libraryFavoritesOnly = false
                        screenName = AppScreen.LIBRARY.name
                    }
                )
                AppScreen.PLAYLISTS -> PlaylistsScreen(
                    playlists = playlists,
                    allItems = visibleMedia,
                    onCreate = { LibraryStore.createPlaylist(activity, it); storeEpoch++ },
                    onDelete = { LibraryStore.deletePlaylist(activity, it); storeEpoch++ },
                    onRename = { old, new -> LibraryStore.renamePlaylist(activity, old, new); storeEpoch++ },
                    onDuplicate = { LibraryStore.duplicatePlaylist(activity, it); storeEpoch++ },
                    onOpen = { if (it.isNotEmpty()) openItems(it, 0) }
                )
                AppScreen.SETTINGS -> SettingsScreen(
                    hiddenCount = hiddenMedia.size,
                    trashCount = trashMedia.size,
                    onThemeChanged = onThemeChanged,
                    onOpenPrivate = ::openPrivate,
                    onOpenTrash = { screenName = AppScreen.TRASH.name },
                    onOpenDiagnostics = { screenName = AppScreen.DIAGNOSTICS.name },
                    onClearHistory = { LibraryStore.clearHistory(activity); storeEpoch++ },
                    onOpenCastSettings = activity::openCastSettings,
                    onLibraryChanged = { storeEpoch++; onThemeChanged() }
                )
                AppScreen.HIDDEN -> HiddenScreen(
                    items = hiddenMedia,
                    onOpenItems = ::openItems,
                    onUnhide = { LibraryStore.setHidden(activity, it, false); storeEpoch++ }
                )
                AppScreen.TRASH -> TrashScreen(
                    items = trashMedia,
                    onBack = { screenName = AppScreen.SETTINGS.name },
                    onOpenItems = ::openItems,
                    onRestore = { LibraryStore.restoreFromTrash(activity, it); storeEpoch++ },
                    onEmptyLogicalTrash = { LibraryStore.emptyTrash(activity); storeEpoch++ }
                )
                AppScreen.DIAGNOSTICS -> DiagnosticsScreen(onBack = { screenName = AppScreen.SETTINGS.name })
            }
        }
    }

    if (showOpenUrl) {
        OpenMediaUrlDialog(
            onDismiss = { showOpenUrl = false },
            onOpen = { media ->
                viewerItems = listOf(media)
                viewerIndex = 0
            }
        )
    }
}

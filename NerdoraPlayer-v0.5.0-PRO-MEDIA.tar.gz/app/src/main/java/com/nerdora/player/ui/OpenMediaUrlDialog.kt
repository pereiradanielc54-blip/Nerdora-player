package com.nerdora.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nerdora.player.model.MediaKind
import com.nerdora.player.model.NerdoraMedia

@Composable
fun OpenMediaUrlDialog(
    onDismiss: () -> Unit,
    onOpen: (NerdoraMedia) -> Unit
) {
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(MediaKind.VIDEO) }
    val valid = url.trim().startsWith("https://") || url.trim().startsWith("http://")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Abrir mídia por link") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Use um link direto autorizado de vídeo, áudio ou imagem (HTTP/HTTPS). HLS e DASH são suportados pelo Media3 quando a fonte permite.")
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL da mídia") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Título (opcional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        MediaKind.VIDEO to "Vídeo",
                        MediaKind.AUDIO to "Áudio",
                        MediaKind.IMAGE to "Imagem"
                    ).forEach { (value, label) ->
                        FilterChip(selected = kind == value, onClick = { kind = value }, label = { Text(label) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    val clean = url.trim()
                    onOpen(
                        NerdoraMedia(
                            id = "network-${clean.hashCode()}",
                            kind = kind,
                            url = clean,
                            title = title.trim().ifBlank { "Mídia online" },
                            description = "Link aberto no Nerdora Player",
                            username = "Rede"
                        )
                    )
                    onDismiss()
                }
            ) { Text("Abrir") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

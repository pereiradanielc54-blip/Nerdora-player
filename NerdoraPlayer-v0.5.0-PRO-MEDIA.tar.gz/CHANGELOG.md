# Changelog

## 0.5.0 — Pro Media / Integration Ready

Versão de fechamento do app independente antes da integração ao Nerdora.

- Índice local SQLite para abrir a biblioteca rapidamente e revalidar o MediaStore em segundo plano.
- Cache reutilizado por até 5 minutos; atualização manual continua disponível.
- Onboarding de primeira execução.
- Mini player com progresso, play/pause, próxima, swipe lateral para anterior/próxima e botão de encerrar a sessão.
- Player de música com fila visual, temporizador de 15/30/45/60 min, seletor de letras `.lrc`/texto e atalho para painel de áudio/equalização disponível no aparelho.
- Velocidade de vídeo persistente entre 0.5x e 2x.
- Ajuste Fit/Zoom/Fill do vídeo salvo como preferência.
- Grade da biblioteca configurável: compacta, normal ou grande.
- Playlists podem ser renomeadas e duplicadas.
- Lixeira lógica do Nerdora: remove da biblioteca do app sem apagar o arquivo físico; permite restaurar.
- Exportação e restauração de favoritos, playlists, histórico e preferências em JSON.
- Tela de diagnóstico com Android, modelo, ABIs e codecs reportados pelo aparelho.
- Abrir mídia por URL HTTP/HTTPS direto da Home (MP4/HLS/DASH/áudio/imagem conforme compatibilidade da fonte e Media3).
- Preferência de reduzir animações.
- Changelog dentro do aplicativo.
- Mantidos: MediaSession, áudio em segundo plano, controles do sistema, PiP, swipe de fotos, zoom, legendas, histórico, favoritos, área oculta, temas e atualização via GitHub Releases.

### Intencionalmente não incluído nesta versão

- Download/extrator de YouTube.
- Nerdora Cinema / catálogo de filmes.
- Cliente SMB/NAS/DLNA dedicado.
- Exclusão física automática de arquivos pela lixeira.
- Crossfade avançado entre músicas.

Esses recursos foram deixados de fora para a base final continuar estável e simples de integrar ao Nerdora.

## 0.4.3 — Compile Fix
- Corrige conflito de receiver do `AnimatedVisibility` no visualizador de mídia.

## 0.4.2 — UX Refinement
- Auto-ocultação do HUD de vídeo em 4 s.
- Configurações de vídeo em painel inferior.
- Swipe de fotos corrigido.
- Mini player persistente.

## 0.4.0 — Media Experience
- Home, biblioteca, busca, pastas, histórico, favoritos, playlists, MediaSession, PiP, legendas, slideshow, área oculta, AMOLED e GitHub Update Checker.

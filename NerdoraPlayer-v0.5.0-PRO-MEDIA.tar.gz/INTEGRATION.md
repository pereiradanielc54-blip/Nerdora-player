# Integração Nerdora ↔ Nerdora Player

A v0.5.0 foi preparada para ser a base de integração ao aplicativo Nerdora.

## 1. Abrir arquivo local pelo Android

Envie um `Intent.ACTION_VIEW` com a URI do arquivo e o MIME type (`video/*`, `audio/*`, `image/*`). O `MainActivity` já interpreta esses três tipos.

## 2. Deep link do Nerdora

Formato:

```
nerdora://player?url=<URL>&type=video&title=<TITULO>&thumbnail=<CAPA>
```

`type` pode ser `video`, `audio` ou `image`.

Exemplo:

```
nerdora://player?url=https%3A%2F%2Fcdn.exemplo.com%2Fvideo.m3u8&type=video&title=Meu%20video
```

## 3. Conteúdo do próprio Nerdora

Ao integrar no app principal, a recomendação é manter o player como uma camada de UI/playback e fornecer a ele um `NerdoraMedia`. Assim o backend social do Nerdora continua sendo responsável por curtidas, comentários, denúncias, permissões e URLs autorizadas.

## 4. MediaSession

`PlaybackService` deve permanecer registrado no Manifest para áudio em segundo plano, Bluetooth, tela bloqueada e controles do sistema.

## 5. Dados locais

- `PlayerPreferences`: preferências e posições de reprodução.
- `LibraryStore`: favoritos, playlists, histórico, ocultos e lixeira lógica.
- `MediaIndexCache`: índice SQLite de metadados locais.

Ao migrar para o app principal, esses objetos podem ser mantidos ou substituídos gradualmente por um repositório/banco central do Nerdora.

## 6. Segurança

A área oculta atual é uma camada de privacidade dentro do app; não criptografa o arquivo físico. Se o Nerdora futuramente oferecer cofre real, use armazenamento criptografado e uma política de migração explícita.
